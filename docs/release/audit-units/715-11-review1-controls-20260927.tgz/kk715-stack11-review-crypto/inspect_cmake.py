import json, subprocess, tempfile
from pathlib import Path

root=Path('/private/tmp/kk715-stack11-resume')
out=Path('/private/tmp/kk715-stack11-review-crypto')
results={}
for variant,privacy,btc in [('full','ON','OFF'),('bitcoin-only','OFF','ON')]:
 with tempfile.TemporaryDirectory(prefix='kk715-review-crypto-') as tmp:
  project=Path(tmp)
  for name in ('lib','include','deps'):
   (project/name).symlink_to(root/name, target_is_directory=True)
  (project/'CMakeLists.txt').write_text('''cmake_minimum_required(VERSION 3.16)
project(review_sources LANGUAGES C CXX)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)
set(KK_BITCOIN_ONLY '''+btc+''')
set(KK_ZCASH_PRIVACY '''+privacy+''')
function(target_link_libraries)
endfunction()
add_subdirectory("'''+str(root)+'''/deps/crypto" crypto)
add_subdirectory("'''+str(root)+'''/unittests" unittests)
get_target_property(crypto_sources trezorcrypto SOURCES)
file(WRITE "${CMAKE_BINARY_DIR}/crypto-sources.txt" "${crypto_sources}")
get_target_property(firmware_sources firmware-unit SOURCES)
file(WRITE "${CMAKE_BINARY_DIR}/firmware-sources.txt" "${firmware_sources}")
if(TARGET zcash-crypto-unit)
 file(WRITE "${CMAKE_BINARY_DIR}/zcash-target.txt" "present")
else()
 file(WRITE "${CMAKE_BINARY_DIR}/zcash-target.txt" "absent")
endif()
''')
  subprocess.run(['cmake','-S',str(project),'-B',str(project/'build'),'-G','Unix Makefiles'],check=True,stdout=subprocess.DEVNULL)
  b=project/'build'
  cmd=json.loads((b/'compile_commands.json').read_text())
  sources=(b/'crypto-sources.txt').read_text().split(';')
  zcash=[p for p in sources if 'pallas' in p or 'zcash_zip316' in p]
  compiled=[p['file'] for p in cmd if 'pallas' in p['file'] or 'zcash_zip316' in p['file']]
  fs=(b/'firmware-sources.txt').read_text().split(';')
  results[variant]={'pallas_zcash_source_entries':zcash,'pallas_zcash_compilation_units':compiled,'standalone_target':(b/'zcash-target.txt').read_text(),'firmware_unit_zcash_source':'zcash.cpp' in fs}
print(json.dumps(results,indent=2))
