#!/bin/sh
set -eu
/evidence/cmake-3.31.6-linux-x86_64/bin/cmake -C /src/cmake/caches/emulator.cmake /src -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER=gcc -DCMAKE_CXX_COMPILER=g++ -DKK_BUILD_DYLIB=ON -DKK_HAVE_STRLCPY=0 -DKK_HAVE_STRLCAT=0 -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
/evidence/cmake-3.31.6-linux-x86_64/bin/cmake --build /build --target kkemulator_dylib -j 8
python3 /evidence/dylib/probe.py
