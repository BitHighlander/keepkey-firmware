import ctypes,glob,json
paths=glob.glob('/build/**/libkkemu.so',recursive=True)
assert len(paths)==1,paths
lib=ctypes.CDLL(paths[0])
for name in ('strlcpy','strlcat'):
    fn=getattr(lib,name)
    fn.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t]
    fn.restype=ctypes.c_size_t
buf=ctypes.create_string_buffer(b'XXXXXXXX',9)
assert lib.strlcpy(buf,b'abcdef',4)==6
assert buf.raw==b'abc\x00XXXX\x00',buf.raw
assert lib.strlcat(buf,b'defgh',6)==8
assert buf.raw==b'abcde\x00XX\x00',buf.raw
before=buf.raw
assert lib.strlcpy(buf,b'abc',0)==3 and buf.raw==before
assert lib.strlcat(buf,b'abc',0)==3 and buf.raw==before
print(json.dumps({'library':paths[0],'forced_libc_fallbacks':'both','load':'pass','strlcpy_bounds':'pass','strlcat_bounds':'pass','zero_capacity':'pass'}))
