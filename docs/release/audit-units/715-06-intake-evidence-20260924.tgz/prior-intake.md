# 7.15 Block 06 audit intake — runtime-provider clear signing

Status: **in progress; not accepted**. This is an audit scope receipt, not the
finished master-template report or a release approval. Main-worktree master
template SHA256: `3087df6a681660b92e8d162149da6759666b484c37fcda2b1d32c3b66dc8ddaa`.

## Frozen starting point

- Fork PR: [#836](https://github.com/BitHighlander/keepkey-firmware/pull/836).
- Adjacent base: `release/715-stack-05-variants` at
  `dc644600361da15a123f0d50605220cccadd8de3`.
- Published head: `b771669ba842d83790a69b6132f63cea82e5a861`.
- Local remediation head (unpublished):
  `c20dab14ddc3156141e1fb70234cd706b1b25392`, tree
  `8d5126bc58828b1632230ba4c4a58a83863d7844`.
- Adjacent diff: 26 files, 1,501 added and 1,006 deleted lines (2,507 total).
- Local audit worktree: `/private/tmp/kk715-06-review`, branch
  `audit/715-stack-06-review-20260922`; no push or CI run from this worktree.
- Exact dependency pins at this head: `deps/crypto/trezor-firmware`
  `8a392f70a5d5575ece3dfb35f115d4a4b27f497c`, `deps/device-protocol`
  `dd9c85dc747cf965fb0e7bf49615dc9e7568ee65`, `deps/python-keepkey`
  `49d537ce953b7524599bfc87f56b7a50a51a13a1`.

## Entry findings and reconciliation required

1. The published Block 06 base is **not a descendant** of accepted Block 00a
   (`9cb72384fd14b2a688a70d17711a7923941d2290`). Do not treat the old
   stack's passing evidence as proof of a sequence containing the accepted
   foundation. Reconstruct through 00b–05 before final Block 06 publication.
2. PR #836 describes runtime-provider metadata, transport and exact-byte
   review, but its adjacent code diff is principally EIP-712 parser, EVM
   contract, display and test changes. Runtime signer loading and the
   AdvancedMode/volatile-signers policy are inherited from its base. Reconcile
   the title/scope against the actual changed files, and classify inherited
   behavior separately from new Block 06 behavior.
3. The prior hosted run `35685551624` has failed integration and report-gate
   jobs despite successful unit and ARM jobs. Do not re-run hosted CI until a
   local Docker preflight explains or resolves those failures.
4. Structured EIP-712 remains disabled by
   `ethereum_structured_eip712_enabled() == false`; parser changes must not be
   represented as a newly enabled signing capability without an explicit
   release decision and proof of displayed/signed byte equivalence.
5. Candidate security finding **B06-001**: the new static `HDNode` in
   `zx_getDerivedNode()` is wiped after successful address derivation, but a
   failed `hdnode_private_ckd_cached()` returns with root/partial private-key
   material still in static RAM. The local remediation wipes the node before
   reuse and on every failure path; focused code/test verification remains.
6. Confirmed regression **B06-002**: this adjacent diff removes the tiny
   receive loop's rejection exit and post-copy buffer wipe from
   `lib/board/messages.c`. A malformed tiny packet can strand a blocking
   handler after its failure response, and a successful secret-bearing ack
   remains in the static tiny buffer. The local remediation restores both
   safeguards and adds `USBRX.MalformedTinyPacketCancelsAndClearsPendingBuffer`.
   The exact-source Docker native suite passes 442 firmware, 19 board and 18
   crypto tests; full integration and variant checks remain pending.
7. Confirmed product-policy defect **B06-003**: the Docker OLED companion test
   `test_no_runtime_slot_can_reach_the_suppression_branch` fails on the old
   Block 06 image. Source inspection confirms `ethereum.c` suppresses the
   ordinary amount/raw-calldata review after approving metadata from a
   runtime-loaded provider. That violates the companion's additive invariant:
   an untrusted provider may add explanation screens, not remove the baseline
   review. The local remediation retains the baseline review for a runtime
   signer. A rebuilt Docker emulator passes the three previously failing
   additive-review tests (v1, all runtime slots, and v2 schema); full-suite
   requalification remains pending. No trusted firmware signer is included in
   this build.
8. Inherited release blocker **B06-004** (not silently assigned to this PR):
   the same Docker companion pass fails session trust-lifetime tests. The old
   predecessor still writes AdvancedMode into storage flags bit 12 and reads
   that bit on boot, while `session_clear()` does not revoke loaded metadata
   signers. The companion contract requires AdvancedMode and provider trust to
   end with the session. This must be fixed in the appropriate predecessor
   unit and then propagated/retested through Block 06; local Block 06 edits
   alone cannot qualify the release stack.
9. The initial full Docker OLED pass on the pre-additive-fix image produced
   **12 failures, 154 passes, 22 skips**. In addition to B06-003/004, one
   generic ERC-20 and one Block-06-touched Uniswap liquidity test expect
   unlimited approvals to be rejected, but both currently sign; three Hive
   tests expose `HIVE` versus `STEEM` wire-symbol and max-memo mismatches.
   These are pending separate technical dispositions, not waived failures.

## Local remediation and validation so far

| Finding | Local commit | Disposition | Verification |
| --- | --- | --- | --- |
| B06-001 static derived key retained on failure | `e5bd8499b` | Fixed locally; no push | Full Docker build and native suite pass; explicit failure-path test seam still desirable. |
| B06-002 rejected tiny receive can hang/retain secret | `2263bdce0` | Fixed locally; no push | New `USBRX.MalformedTinyPacketCancelsAndClearsPendingBuffer` included in passing native suite. |
| B06-003 runtime metadata suppresses baseline review | `c20dab14d` | Fixed locally; no push | Three previously failing additive-review integration tests pass on rebuilt emulator. |

The rebuilt full emulator image is
`sha256:9ffaccf6b14c3efb9e563888db9fdae332deb295bff647e876cf62642134a3bb`.
On the same code snapshot, local Docker native xunit passes 442 firmware,
19 board, and 18 crypto tests. The Bitcoin-only image
`sha256:5f70208a1f0b7faa56db6d968f2d9fd61d5c4cac3a7039d2e9a1a01f33ee4b5d`
builds and passes 122 firmware, 19 board and 18 crypto tests. This is focused
evidence only: the first full
OLED pass was against the pre-B06-003 image and had the 12 failures above.
No clean full-suite claim is made. Bitcoin-only companion, ARM/SRAM, report render,
restack, exact-head hosted CI and human audit remain open.

## Acceptance contract

- Audit every changed source, test, dependency and workflow path against this
  adjacent base; resolve or technically disposition each in-scope finding.
- Preserve AdvancedMode-only, RAM-only, session-scoped runtime signers and
  exclude any KeepKey/alpha trusted root; prove no metadata bypasses exact
  transaction-byte review.
- Establish whether the EIP-712, THORChain and liquid-contract changes belong
  in this unit, need smaller units, or should be withdrawn. Check test
  registration and actual execution, not merely test presence.
- Pass focused regressions and full regular/Bitcoin-only Docker preflight,
  inspect named skips and artifacts, then pass applicable ARM/SRAM checks.
- Reconcile this block onto the accepted predecessor sequence; verify exact
  pins, tree, adjacent line gate, and prior-unit interactions. Only then
  request **one** hosted CI run for the frozen Block 06 head.
- Complete the master-template source/PDF inventory and exact-head review
  checkpoint before marking Block 06 accepted. Physical-device and release
  promotion gates remain separate.
