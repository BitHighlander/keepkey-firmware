import ast,json,subprocess
from pathlib import Path
fw=Path('/private/tmp/kk715-stack08-on-7b'); py=Path('/private/tmp/kk715-stack08-python')
def git(root,*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
paths=git(fw,'diff','--name-only','dc8c80ec9^','dc8c80ec9').splitlines()
assert len(paths)==23
mapping={
'eip712_stream':('retained','Current Eip712Stream.CertifiedFieldReplayPreservesDomainAndSigningPath and Erc7730Workflow.TypedDataReplayBindsBothDomainAndMessageHashes; ordinary leaf review and final consent retained.'),
'erc7730_abi':('bounded replacement','Current ABI class/capture definitions; one active full array only, nesting/slices refused by capability table and compiler.'),
'erc7730_abi_stream':('retained with bounded iteration','Current ABI stream validates canonical bytes and captures inner offsets; nested dynamic validation is distinct from nested display iteration. EX16/EX33 and compiler refusal checks retain the 7.15 bound.'),
'erc7730_catalog':('replacement in 7b','Current verifier and capability mirror reject unsupported conditions/kinds and preserve nested groups. Erc7730Catalog.GroupFramesPreservePathClasses and D iteration cases cover replacement.'),
'erc7730_condition':('deferred runtime conditions','Optional opcode3 always visible. All hiding/veto conditions refused at preload. Old membership/mustMatch helpers are not enabled; enum handled by current field/program path.'),
'erc7730_format':('replacement in 7b','Field formatters implement date/duration/unit/enum with raw values and signer provenance. B08-001 NUL truncation is covered by EscapesStringCapturesAndRejectsSmallOutput. Raw formatter callers pass bounded captures or fixed32-byte words.'),
'erc7730_program':('bounded replacement','Current table/string/literal parsers and capability checks replace old metadata fetches. Token/chain facts come from firmware tables; signer metadata never upgrades asset trust.'),
'erc7730_workflow':('replacement plus Stack08 regression coverage','Current replay digest binds complete outer bytes during inner validation, restores saved parent ID and clears inner state. EX40-44 add transport/restoration/cancel coverage; unsupported nested loops remain refused.'),
'ethereum':('retained signing binding','Current signing continuation checks validated calldata digest and preserves baseline transaction/data-hash review; runtime signature equivalence is asserted.'),
'fsm_msg_ethereum':('replacement plus Stack08 regression coverage','Current FETCH dispatch enforces ID/chunk sequence and chain/callee/selector before inner screens, restores outer state, uses explicit blind fallback and abort cleanup; EX40-44 exercise handlers.'),
}
rows=[]
for path in paths:
 stem=Path(path).stem
 disposition,evidence=mapping[stem]
 rows.append({'historical_path':path,'disposition':disposition,'evidence':evidence})
module='tests/test_msg_ethereum_erc7730_runtime.py'
old=ast.parse(git(py,'show','5c2dd4d:'+module));new=ast.parse((py/module).read_text())
def methods(tree):return {node.name:ast.dump(node,include_attributes=False) for cls in tree.body if isinstance(cls,ast.ClassDef) for node in cls.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')}
a,b=methods(old),methods(new)
assert set(a)<=set(b)
assert all(a[k]==b[k] for k in a)
assert len(a)==39 and len(b)==44
assert git(fw,'diff','248397752','HEAD','--','lib','unittests','include/keepkey/firmware')==''
assert git(py,'diff','5c2dd4d','HEAD','--','keepkeylib')==''
result={'base':'2483977523d9b6beab52a69429ace9aeefd00f76','code_snapshot':git(fw,'rev-parse','HEAD'),'python_base':'5c2dd4dbce5096de393b2db8c925f24950e22d8b','python_head':git(py,'rev-parse','HEAD'),'historical_commit':'dc8c80ec99a84b7f5381759ac03e041b2aadb92f','historical_paths':rows,'preservation':{'runtime_before':len(a),'runtime_after':len(b),'removed':[],'changed_predecessor_test_bodies':[],'firmware_lib_headers_native_tests':'unchanged','python_keepkeylib':'unchanged'}}
Path('/private/tmp/kk715-stack08-reconciliation.json').write_text(json.dumps(result,indent=2)+'\n')
# Negative control for the preservation alarm.
b.pop(next(iter(a)))
assert not set(a)<=set(b)
print('23 historical paths mapped; all39 predecessor test ASTs unchanged; removal control rejected')
