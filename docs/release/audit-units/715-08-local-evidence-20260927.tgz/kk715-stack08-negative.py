from pathlib import Path
import subprocess
source=Path('/private/tmp/kk715-stack08-python/tests/test_msg_ethereum_erc7730_runtime.py').read_text()
controls={
 'outer_bytes_changed_during_inner_review_are_refused':('altered[127] = 1','altered[127] = 0'),
 'restoring_outer_definition_rejects_another_valid_definition':('definition_id=wrong.definition_id, offset=0,\n                        total_length=len(wrong.envelope),\n                        data=wrong.envelope[:request.length]','definition_id=outer_def.definition_id, offset=0,\n                        total_length=len(outer_def.envelope),\n                        data=outer_def.envelope[:request.length]'),
 'inner_definition_identity_cannot_change_between_chunks':('response.definition_id = bytes(32)','response.definition_id = inner_def.definition_id'),
 'cancelled_inner_review_clears_preload_in_the_same_session':('arguments=arguments, cancel_title=title,','arguments=arguments, cancel_title="never",'),
}
for name,(old,new) in controls.items():
 assert source.count(old)==1,(name,source.count(old))
 path=Path('/private/tmp/test_msg_ethereum_erc7730_stack08_negative.py')
 path.write_text(source.replace(old,new))
 subprocess.run(['docker','cp',str(path),'kk715-er-audit:/tmp/'+path.name],check=True)
 cmd=['docker','exec','-e','PYTHONPATH=/tmp/stack08-python:/tmp/stack08-python/tests','-e','KK_TRANSPORT_MAIN=127.0.0.1:11044','-e','KK_TRANSPORT_DEBUG=127.0.0.1:11045','-e','FW_VERSION=7.15.0','kk715-er-audit','python3','-m','pytest','-q','--disable-warnings','-x','/tmp/'+path.name+'::TestMsgEthereumErc7730Runtime::test_'+name]
 result=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 Path('/private/tmp/kk715-stack08-negative-'+name+'.log').write_text(result.stdout)
 assert result.returncode==1 and '1 failed' in result.stdout,result.stdout
 print(name+': expected failure',flush=True)
