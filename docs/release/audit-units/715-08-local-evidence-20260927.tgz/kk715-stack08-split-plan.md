# Stack 08 — one authorized binary breakdown

Owner authorization: latest goal permits three initial requests total, one breakdown, then three requests per resulting unit. Initial requests are exhausted: Python clean, firmware two finding-bearing reviews. No recursive split or additional initial request.

## A: Report evidence and wire-contract pin
Base: accepted consolidated 7b 2483977523d9b6beab52a69429ace9aeefd00f76.
Files: report generator, report tests, CI report-test/history steps and companion PR metadata, Python pin, duplicate nanopb option removal, current source/PDF/reconciliation/local evidence.
Findings: 4114517037 authority selected by candidate constant; 4114517067 empty ledger; 4114517093 skip reasons. Earlier B08-004 retained and repaired.
Python #120 remains at its clean reviewed head d9a02d981ee43fe3e80b28ba02466670e6e8409d. No additional Python change or request planned; any needed request counts within A's three.

## B: Preflight and static analysis
Base: final A head, stacked.
Files: scripts/preflight.sh, shared explicit cppcheck invocation/version files and focused regression tests, CI static-analysis install/invocation and matching test step, B source/PDF/evidence.
Findings: 4114517060 extraction; 4114517076 stale analyzer; 4114517108 duplicate suite.
The extraction finding's exact alleged shell corruption will be reproduced or technically dispositioned; shared arguments remove parsing fragility regardless.

Each unit gets at most three registered Copilot requests, including any companion request. Preserve #872 and #120; no history rewrite/force-push. Close all concrete findings after pushed fixes, retain mapping and retrospectives. Final acceptance requires local qualification, exact-head CI/report identity and clean review of each adjacent code-bearing diff. Stop for the night when this single breakdown's budgets fail; no further split. Consolidate final accepted tree into #872 without an additional review request, preserving child review coverage receipts.
