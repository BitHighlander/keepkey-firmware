import subprocess,sys,re
def sh(*a):
    return subprocess.run(a,capture_output=True,text=True,cwd='/private/tmp/kk715-b13').stdout
def presence(label,B,T,H='HEAD'):
    for o in (B,T):
        if subprocess.run(['git','cat-file','-e',o],cwd='/private/tmp/kk715-b13').returncode: print(label,'object missing',o); return
    files=[f for f in sh('git','diff','--name-only','--diff-filter=AM',B,T,'--','.',':!docs',':!deps').split('\n') if f]
    tot=pres=0; missing_files=[]; gone={}
    for f in files:
        d=sh('git','diff','-U0',B,T,'--',f)
        added=[l[1:] for l in d.split('\n') if l.startswith('+') and not l.startswith('+++')]
        added=[l.strip() for l in added if len(l.strip())>3]
        if not added: continue
        cur=sh('git','show',f'{H}:{f}')
        if subprocess.run(['git','cat-file','-e',f'{H}:{f}'],cwd='/private/tmp/kk715-b13').returncode:
            missing_files.append((f,len(added))); tot+=len(added); continue
        curset=set(l.strip() for l in cur.split('\n'))
        k=sum(1 for l in added if l in curset); tot+=len(added); pres+=k
        if k<len(added): gone[f]=len(added)-k
    pct=100.0*pres/tot if tot else 100.0
    print(f'{label:18s} files={len(files):4d} added-lines={tot:6d} present-in-B13={pres:6d} ({pct:5.1f}%)  files-absent-in-B13={len(missing_files)}')
    top=sorted(gone.items(),key=lambda x:-x[1])[:3]
    if top: print('     most-missing:', ', '.join(f'{f.split("/")[-1]}(-{n})' for f,n in top))
    if missing_files: print('     absent files:', ', '.join(f.split('/')[-1] for f,_ in missing_files[:4]))
import subprocess as sp
base4=sp.run(['gh','pr','view','834','--repo','BitHighlander/keepkey-firmware','--json','baseRefOid','--jq','.baseRefOid'],capture_output=True,text=True).stdout.strip()
presence('Block4 #834 (IN)',base4,'f05bfe96d')
presence('Block5 #858 (IN)','f05bfe96d','5c3f2d927')
presence('Block8 #872 (IN)','248397752','db7c711a6')
presence('Block9 #875 (IN)','db7c711a6','ad7a3fe0d')
presence('00a #844','fc1e93746','9cb72384f')
presence('00b #856','9cb72384f','8126f802f')
presence('Block2 #855','51411c4a7c96137bc80f8b99fa1690c4e385f7fd','9237d0a30004dbc079dcf3c1577b2895bc50c73a')
presence('Block3 #833','9237d0a30004dbc079dcf3c1577b2895bc50c73a','5aa047e4d')
presence('Stack01 #831','4c56e19e3070772a28b2890a4ec862ecf77d5429','752466b25')
presence('Block6 #859','5c3f2d927','9a177aa21')
