from pathlib import Path
import subprocess
root=Path('/private/tmp/kk715-stack07-provisional')
evidence=Path('/private/tmp/kk715-stack07-remediation-evidence')
paths=[root/'lib/firmware/erc7730_workflow.c',root/'lib/firmware/eip712_stream.c']
original={p:p.read_bytes() for p in paths}
image='kktech/firmware@sha256:7438e53933d47d53157ed6d96d864cb208597e62dce26235ace09d1063427fa2'
base=['docker','run','--rm','-e','SDL_VIDEODRIVER=dummy','-v',str(root)+':/src','-v','/private/tmp/kk715-stack07-provisional-build-full:/build','-v',str(evidence)+':/evidence']
def build(log):
 with (evidence/log).open('w') as f:
  subprocess.run(base+['-w','/build',image,'cmake','--build','.','--target','firmware-unit','--','-j3'],stdout=f,stderr=subprocess.STDOUT,check=True)
try:
 p=paths[0];s=p.read_text();old='const bool matches = !workflow->reviewed_digest_set ||';assert s.count(old)==2;s=s.replace(old,'const bool matches = true || !workflow->reviewed_digest_set ||');p.write_text(s)
 p=paths[1];s=p.read_text();old='} else if (memcmp(e712.schemas[schema_index].digest, schema_digest, 32)';assert old in s;s=s.replace(old,'} else if (false && memcmp(e712.schemas[schema_index].digest, schema_digest, 32)')
 old='inner->array_levels[inner->levels_total - 1u - inner->level_index]';assert old in s;s=s.replace(old,'0');p.write_text(s)
 build('negative-control-build.log')
 with (evidence/'negative-controls.log').open('w') as f:
  r=subprocess.run(base+['-w','/tmp',image,'/build/bin/firmware-unit','--gtest_filter=Erc7730Workflow.SigningReplayMustMatchReviewedBytesAcrossChunkBoundaries:Erc7730Workflow.TypedDataReplayBindsBothDomainAndMessageHashes:Eip712Stream.RefusesSchemaChangesAfterDiscoveryAndHashing:Eip712Stream.NestedFixedArrayChecksOuterAndInnerDimensions','--gtest_output=xml:/evidence/negative-controls.xml'],stdout=f,stderr=subprocess.STDOUT)
 if r.returncode!=1: raise RuntimeError('Mutations did not produce expected regression failures: '+str(r.returncode))
finally:
 for p,content in original.items(): p.write_bytes(content)
 build('restored-build.log')
 for p,content in original.items(): assert p.read_bytes()==content
print('Mutation run failed as expected; original sources restored byte for byte and rebuilt.')
