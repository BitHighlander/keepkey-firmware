#!/bin/sh
set -eu
cp /evidence/kkemu-full /tmp/kkemu
chmod +x /tmp/kkemu
mkdir /tmp/emulator-work
cd /tmp/emulator-work
/tmp/kkemu > /evidence/emulator-${VARIANT}.log 2>&1 &
export KK_TRANSPORT_MAIN=127.0.0.1:11044
export KK_TRANSPORT_DEBUG=127.0.0.1:11045
export KK_EMULATOR_BIN=/tmp/kkemu
export PYTHONPATH=/audit-host
cd /audit-host/tests
export KEEPKEY_SCREENSHOT=1
export SCREENSHOT_DIR=/evidence/contract-screenshots
export KEEPKEY_SCREENSHOT_TESTS='test_msg_ripple_sign_tx::test_memo_length_prefix_boundaries
test_msg_ethereum_clearsign_additive::test_successful_decode_still_runs_the_raw_review
test_msg_ethereum_clearsign_additive::test_v2_schema_decode_still_runs_the_raw_review'
pytest -v --tb=short -p no:cacheprovider test_msg_ripple_sign_tx.py test_msg_ethereum_clearsign_additive.py --junitxml=/evidence/contract-screenshots.xml
