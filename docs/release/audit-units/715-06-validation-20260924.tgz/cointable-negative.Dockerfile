FROM kk715-stack06-agent1-allowance-full:local
COPY unittests/firmware/fsm.cpp /kkemu/unittests/firmware/fsm.cpp
RUN make -j4 firmware-unit
