#!/bin/sh
set -eu
mkdir /tmp/firmware-build
cd /tmp/firmware-build
if [ "$VARIANT" = btc ]; then variant_flag=-DKK_BITCOIN_ONLY=ON; else variant_flag=; fi
cmake -C /source/cmake/caches/device.cmake /source -DCMAKE_BUILD_TYPE=MinSizeRel $variant_flag
make -j4
mkdir -p /evidence/arm-${VARIANT}
cp bin/*.elf bin/*.bin /evidence/arm-${VARIANT}/
arm-none-eabi-size bin/firmware.keepkey.elf
