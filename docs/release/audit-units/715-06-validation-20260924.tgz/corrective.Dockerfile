ARG PREVIOUS
FROM ${PREVIOUS}
COPY lib/firmware/eip712.c /kkemu/lib/firmware/eip712.c
COPY lib/firmware/storage.c /kkemu/lib/firmware/storage.c
COPY include/keepkey/firmware/eip712.h /kkemu/include/keepkey/firmware/eip712.h
COPY unittests/firmware/ethereum.cpp /kkemu/unittests/firmware/ethereum.cpp
COPY unittests/firmware/eip712.cpp /kkemu/unittests/firmware/eip712.cpp
COPY unittests/firmware/storage.cpp /kkemu/unittests/firmware/storage.cpp
RUN make -j4
