import os
from keepkeylib.client import KeepKeyClient
from keepkeylib.transport_udp import UDPTransport
from keepkeylib import messages_pb2 as proto
client = KeepKeyClient(UDPTransport('127.0.0.1:11044'))
try:
    table = client.call(proto.GetCoinTable())
    assert table.chunk_size == 24, table.chunk_size
    counts = [2] if table.num_coins == 2 else [10, 24]
    for count in counts:
        response = client.call(proto.GetCoinTable(start=0, end=count))
        assert isinstance(response, proto.CoinTable), response
        assert len(response.table) == count, len(response.table)
        assert response.table[0].coin_name == 'Bitcoin', response.table[0]
        print('PASS CoinTable wire response:', count, 'entries; advertised capacity', table.chunk_size)
finally:
    client.close()
