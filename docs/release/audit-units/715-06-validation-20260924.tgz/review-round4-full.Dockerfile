FROM kk715-stack06-cointable-full:local
COPY include/keepkey/firmware/tiny-json.h /kkemu/include/keepkey/firmware/tiny-json.h
COPY lib/firmware/eip712.c /kkemu/lib/firmware/eip712.c
COPY unittests/firmware/eip712.cpp /kkemu/unittests/firmware/eip712.cpp
RUN make -j4 firmware-unit
