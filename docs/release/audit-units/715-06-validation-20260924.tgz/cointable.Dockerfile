ARG PREVIOUS
FROM ${PREVIOUS}
COPY include/keepkey/transport/messages.options /kkemu/include/keepkey/transport/messages.options
COPY unittests/firmware/fsm.cpp /kkemu/unittests/firmware/fsm.cpp
RUN make -j4
