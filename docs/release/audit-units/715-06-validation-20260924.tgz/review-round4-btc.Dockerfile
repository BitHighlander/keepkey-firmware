FROM kk715-stack06-cointable-btc:local
COPY include/keepkey/firmware/tiny-json.h /kkemu/include/keepkey/firmware/tiny-json.h
RUN make -j4 firmware-unit
