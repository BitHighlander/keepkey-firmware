#!/bin/sh
set -eu
python3 - <<'PY'
p='lib/firmware/ethereum.c'
s=open(p).read().replace('if (!signed_metadata_from_loaded_signer()) {', 'if (true) {')
open(p,'w').write(s)
PY
make -j4 kkemu
cp bin/kkemu /evidence/kkemu-additive-negative
