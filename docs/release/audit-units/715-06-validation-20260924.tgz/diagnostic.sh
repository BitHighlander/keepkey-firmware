#!/bin/sh
set -e
cmake -DCMAKE_CXX_FLAGS=-DKK_FINAL_POLICY_TESTS .
make -j4 firmware-unit
./bin/firmware-unit --gtest_filter='Fsm.*:AutoLockProgress.*' --gtest_output=xml:/evidence/diagnostic-${VARIANT}.xml
