#!/bin/sh
set -e
python3 - <<'PYCODE'
p='lib/board/messages.c'
s=open(p).read().replace('while (msg_tiny_id == MSG_TINY_TYPE_ERROR && !tiny_handler_rejected)', 'while (msg_tiny_id == MSG_TINY_TYPE_ERROR)')
s=s.replace('  if (tiny_handler_rejected) {\n    memzero(msg_tiny, sizeof(msg_tiny));\n    memzero(buf, MSG_TINY_BFR_SZ);\n    return MessageType_MessageType_Cancel;\n  }\n', '')
open(p,'w').write(s)
PYCODE
make -j4 firmware-unit
./bin/firmware-unit --gtest_filter=USBRX.MalformedTinyPacketCancelsAndClearsPendingBuffer --gtest_output=xml:/evidence/tiny-negative-${VARIANT}.xml
