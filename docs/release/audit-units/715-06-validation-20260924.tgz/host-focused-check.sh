#!/bin/sh
set -eu
apk add --no-cache lsof procps
cp /evidence/kkemu-full /tmp/kkemu
chmod +x /tmp/kkemu
mkdir /tmp/emulator-work
cd /tmp/emulator-work
/tmp/kkemu > /evidence/emulator-focused.log 2>&1 &
export KK_TRANSPORT_MAIN=127.0.0.1:11044
export KK_TRANSPORT_DEBUG=127.0.0.1:11045
export KK_EMULATOR_BIN=/tmp/kkemu
export PYTHONPATH=/audit-host
cd /audit-host/tests
pytest -v --tb=short -p no:cacheprovider test_msg_session_trust_lifetime.py test_msg_ethereum_clearsign_additive.py test_msg_ripple_sign_tx.py test_msg_ethereum_signing_guards.py --junitxml=/evidence/host-contracts.xml
