#!/bin/sh
set -eu
python3 - <<'MUTATE'
p='lib/firmware/eip712.c'
s=open(p).read().replace('if (!hex_string_is_valid(dsverifyingContract, 20, true)) {','if (false) {').replace('if (!eip712_parse_canonical_u32(dschainId, &chainInt)) {','if (false) {')
open(p,'w').write(s)
MUTATE
make -j4 firmware-unit
set +e
./bin/firmware-unit --gtest_filter='EIP712.DomainContractValidatesEvenWhenDeclaredString:EIP712.DomainChainIdRejectsNoncanonicalAndOverflowValues' --gtest_output=xml:/evidence/corrective-negative.xml
status=$?
set -e
test "$status" -ne 0
echo 'Removed domain guards were detected'
