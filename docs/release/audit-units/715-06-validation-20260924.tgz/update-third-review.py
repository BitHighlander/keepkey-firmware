from pathlib import Path
import json
root=Path('/private/tmp/kk715-stack06-intake-evidence')
p=root/'pr-body.md';s=p.read_text()
s=s.replace('ff956077fa65726d28c0d7055a565a7607883fa1','efdeb678bc33c616cf8048fb5773548f0da96fa7').replace('fad2d0c4af0e186a9e16837cd844413feb552306','7d76cd47c2c3f50905224b32402e9e5e815e526c').replace('f49c68ccf','822314c92').replace('**53**','**52**').replace('all 53','all 52').replace('**488 firmware','**489 firmware').replace('**134 /','**135 /')
s=s.replace('- Local final full native', '- Earlier allowance-only full native')
s=s.replace('Bitcoin-only implementation is unchanged by the allowance repair; final-head CI repeats both variants.', 'The subsequent CoinTable capacity repair affects both variants; local native counts are now 489/135 and complete host totals remain unchanged.')
start=s.index('- Eight PDF pages inspected;')
s=s[:start]+'''- Eight PDF pages inspected; all 52 adjacent paths/counts match. Previous-head CI 35964456381 passed. **Final-head CI for `efdeb678bc33c616cf8048fb5773548f0da96fa7` is running**; its result will be recorded here.
- Third owner-authorized review [5302461413](https://github.com/BitHighlander/keepkey-firmware/pull/859#pullrequestreview-5302461413) on `ff956077f`: **Needs a closer look; Findings: None**, zero inline findings, Lite effort. Request registered 2026-09-24T09:17:35Z, timeline event 31743363305. All six earlier threads remain resolved.
- Its **body-only CoinTable compatibility concern was confirmed and repaired** in `7d76cd47c`: restore accepted-predecessor capacity 24 because bundled HDWallet requests 10 by default. The new native regression fails against capacity 8 and passes after repair; actual full protocol responses return 10/24 entries and BTC returns its two entries. Both ARM linker reserve gates pass after the 3,768-byte bss increase per variant.
- Full/BTC native: **489 / 135 firmware tests**, plus 19 board and 18 crypto each. Full/BTC broad host: **653/178 and 347/484 pass/skip**, zero failures.
- **Three reviews delivered; zero unresolved threads.** The latest review predates the compatibility repair. No clean current-head external checkpoint is claimed. A fourth request requires renewed owner direction under REHEARSAL-SOP; internal readiness remains separate from external checkpoint status.

Physical devices, signed upgrade, earlier predecessor propagation into the assembled release, and release promotion remain separate. PR #836 remains historical; this PR is the reconciled code-bearing audit against the completed immediate predecessor. No develop merge or release publication is proposed.
'''
p.write_text(s);(root/'pr-update.json').write_text(json.dumps({'body':s}))
body='''Disposition of the body-only CoinTable concern in Copilot review 5302461413:

Confirmed and fixed in 7d76cd47c2c3f50905224b32402e9e5e815e526c (published final report head efdeb678bc33c616cf8048fb5773548f0da96fa7). The replay reduced capacity from predecessor 24 to 8; bundled HDWallet requests 10 by default and received Failure_Other. Restored capacity 24, so messages.options no longer differs from accepted Stack 05.

The new native regression fails three assertions against old capacity 8 and passes after repair. Wire checks decode full 10/24-entry responses and BTC's two-entry response. Full/BTC native 489/135, host 653/347 pass (178/484 named skips); both ARM products link with required RAM reserve despite the 3,768-byte bss increase. Report source, inspected eight-page PDF, exact 52-path adjacent inventory and hashed evidence are committed. Final-head CI is running.

The review's literal result was Findings: None with zero inline comments, but this specific body concern needed a code change. All six earlier threads are resolved. The review covers ff956077f, not the repaired current head; no clean current-head review is claimed. Three requests have been spent; no fourth request has been issued.'''
(root/'third-disposition.json').write_text(json.dumps({'body':body}))
