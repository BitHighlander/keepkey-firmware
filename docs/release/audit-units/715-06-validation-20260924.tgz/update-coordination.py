from pathlib import Path
root=Path('/Users/highlander/WebstormProjects/keepkey-stack/projects/keepkey-firmware/docs/release')
status="""

## Stack 06 external review remediation (2026-09-24)

Current audit PR is #859 against completed Stack 05 `5c3f2d927`; #836 is historical. All required hosted CI jobs passed on `f274e6b16` in run 35952907048. Initial Copilot request delivered review 5299708246 on that head, verdict **Changes recommended**, five inline findings plus body observations. Do not mark this head accepted. Corrective code commit `1ebb3b8ec` restores strict domain validation/refusal, state cleanup, canonical integers, all 16 deleted predecessor Ethereum regression tests, and known legacy ShapeShift preference migration. The linkage finding is refuted by existing full source registration, Bitcoin-only stub and both actual product links; exact disposition will accompany the pushed candidate. Full/BTC ARM links and targeted/native checks pass; full integration, report refresh and the single corrective review are in progress. No merge or release acceptance.
"""
for name in ['MASTER-AUDIT-TEMPLATE.md','audit-claims/715-06/OWNER.md']:
 p=root/name;s=p.read_text();s+=status
 if name.endswith('OWNER.md'):
  s=s.replace('- Status: claimed, predecessor reconciliation and audit intake in progress; no acceptance.','- Current status: review remediation on PR #859; Stack 06 not accepted. See latest dated section.').replace('- Stack 05 remains owned by agent 2. Its reconciled audit PR #858 head 41de705c9c16da65bb3c390ab8dc1136b462803c is provisional, not accepted.','- Stack 05 audit checkpoint is complete at `5c3f2d927` (PR #858); agent 2 now owns Stack 07. Earlier intake statements below are historical.')
 else:
  lines=s.splitlines()
  for i,line in enumerate(lines):
   if line.startswith('| Release Stack 06 —'):
    lines[i]='| Release Stack 06 — runtime-provider clear signing | **Review remediation; not accepted.** Reconciled code-bearing [PR #859](https://github.com/BitHighlander/keepkey-firmware/pull/859) targets completed Stack 05 `5c3f2d927`; PR #836 is historical. | Exact-head CI on `f274e6b16` passed; Copilot review 5299708246 delivered five findings. Corrective code `1ebb3b8ec` is under revalidation. | See claim, committed source/PDF report and latest remediation receipt. One corrective review remains; release gates stay separate. |'
  s='\n'.join(lines)+'\n'
 p.write_text(s)
