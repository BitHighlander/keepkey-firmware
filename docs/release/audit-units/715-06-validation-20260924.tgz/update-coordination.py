from pathlib import Path
root=Path('/Users/highlander/WebstormProjects/keepkey-stack/projects/keepkey-firmware/docs/release')
for name in ['MASTER-AUDIT-TEMPLATE.md','audit-claims/715-06/OWNER.md']:
 p=root/name;s=p.read_text();s=s.replace('Final-head hosted CI running.', 'Final-head hosted CI **35982066194 passed every required job** on `efdeb678bc33c616cf8048fb5773548f0da96fa7`, including full/BTC ARM/emulator/native/host/OLED, generated report and final evidence gates. Local implementation and software validation are complete; external current-head review remains separate.')
 s=s.replace('compatibility fix validated locally, final CI running.', 'compatibility fix published at efdeb678b; exact-head CI 35982066194 passed.').replace('body concern repaired, final CI running.', 'body concern repaired; exact-head CI 35982066194 passed.')
 p.write_text(s)
