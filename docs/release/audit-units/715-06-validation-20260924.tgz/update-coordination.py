from pathlib import Path
root=Path('/Users/highlander/WebstormProjects/keepkey-stack/projects/keepkey-firmware/docs/release')
receipt="""

## Stack 06 corrective candidate frozen (2026-09-24T06:04:54Z)

PR #859 head `8ed653517a63278891353bcf939a9c3108feacb2` targets Stack 05 `5c3f2d927f56a8646178d00c0abc9ed01c427393`. All required exact-head CI jobs passed in run 35960650402 (publication intentionally skipped). Full local native 485/19/18/72, BTC 134/19/18; broad host full 653 pass/178 skip, BTC 347 pass/484 skip. Full/BTC ARM link and memory gates passed. Domain-guard negative control fails both targeted regressions. Seven PDF pages inspected; all 53 adjacent paths and counts match. Implementation head `1ebb3b8ec72765eec1dea7d668cd744fcfc45881`; no implementation changes since its validation.

Initial review 5299708246 has five explicitly dispositioned, resolved threads and a body-observation disposition in PR comment 5808653495. Corrective request registered at 06:04:54Z, timeline event 31732522259; exactly two requests total, no further request without owner direction. Corrective delivery is pending, so this is not yet a clean code-review checkpoint. Physical-device, prior-predecessor release assembly and promotion remain separate.
"""
for name in ['MASTER-AUDIT-TEMPLATE.md','audit-claims/715-06/OWNER.md']:
 p=root/name;s=p.read_text()+receipt
 if name.endswith('OWNER.md'):s=s.replace('- Current status: review remediation on PR #859; Stack 06 not accepted. See latest dated section.','- Current status: corrective review pending on PR #859 head `8ed653517`; exact-head CI passed. Stack 06 not yet accepted. See latest dated section.')
 else:
  s='\n'.join('| Release Stack 06 — runtime-provider clear signing | **Corrective review pending; not accepted.** [PR #859](https://github.com/BitHighlander/keepkey-firmware/pull/859) head `8ed653517` targets completed Stack 05 `5c3f2d927`. | Exact-head CI 35960650402 passed. Initial review findings are dispositioned; zero unresolved threads. Second/final authorized request registered 06:04:54Z. | Await current-head review; local/report/predecessor gates pass. Physical/release gates remain separate. |' if l.startswith('| Release Stack 06 —') else l for l in s.splitlines())+'\n'
 p.write_text(s)
