from pathlib import Path
root=Path('/Users/highlander/WebstormProjects/keepkey-stack/projects/keepkey-firmware/docs/release')
for name in ['MASTER-AUDIT-TEMPLATE.md','audit-claims/715-06/OWNER.md']:
 p=root/name;s=p.read_text();s+='\n\n## Stack 06 owner-authorized third review\n\nOwner explicitly authorized another Copilot review. Request 3 registered at 2026-09-24T09:17:35Z, timeline event 31743363305, on unchanged final head `ff956077fa65726d28c0d7055a565a7607883fa1` of PR #859. Base remains `5c3f2d927`; CI 35964456381 passed and all six prior threads are resolved. Review delivery is pending; no clean external checkpoint yet. Earlier renewed-authorization blockers above are historical.\n'
 s=s.replace('external review decision required.','third owner-authorized external review pending.').replace('External review checkpoint awaits renewed owner direction.','Owner-authorized third review delivery pending.').replace('Another current-head review requires renewed owner direction.','Owner-authorized third review registered 09:17:35Z; delivery pending.')
 p.write_text(s)
