#!/bin/sh
set -eu
cp /evidence/kkemu-${VARIANT} /tmp/kkemu
chmod +x /tmp/kkemu
mkdir /tmp/emulator-work
cd /tmp/emulator-work
/tmp/kkemu > /evidence/emulator-${VARIANT}.log 2>&1 &
export KK_TRANSPORT_MAIN=127.0.0.1:11044
export KK_TRANSPORT_DEBUG=127.0.0.1:11045
export KK_EMULATOR_BIN=/tmp/kkemu
export PYTHONPATH=/audit-host
cd /audit-host/tests
export KEEPKEY_SCREENSHOT=1
export SCREENSHOT_DIR=/evidence/screenshots-${VARIANT}
export KEEPKEY_SCREENSHOT_TESTS="$(python3 ../scripts/generate-test-report.py --screenshot-test-list --fw-version=7.15.0)"
pytest -v --tb=short -p no:cacheprovider --junitxml=/evidence/screenshots-${VARIANT}.xml
python3 ../scripts/generate-test-report.py --screenshot-audit="$SCREENSHOT_DIR" --audit-junit=/evidence/screenshots-${VARIANT}.xml --fw-version=7.15.0
