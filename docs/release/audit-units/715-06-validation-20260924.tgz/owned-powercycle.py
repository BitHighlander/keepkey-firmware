"""Run unchanged power-cycle assertions with an explicitly owned process.
Avoid lsof/qemu name discovery; track only Popen handles created by this driver.
"""
import os
import subprocess
import sys
import tempfile
import time
import unittest
sys.path.insert(0, '/audit-host/tests')
import test_msg_session_trust_lifetime as tests
binary = '/tmp/kkemu'
workdir = tempfile.mkdtemp(prefix='s06-owned-flash-')
original_popen = subprocess.Popen
owned = [original_popen([binary], cwd=workdir, stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL)]
def tracked_popen(args, *a, **kw):
    process = original_popen(args, *a, **kw)
    if args == [binary]:
        owned[0] = process
    return process

def owned_process(port):
    assert port == 11044
    process = owned[0]
    if process.poll() is not None:
        return None
    return process.pid, binary, workdir

subprocess.Popen = tracked_popen
tests._emulator_process = owned_process
time.sleep(1)
try:
    suite = unittest.defaultTestLoader.loadTestsFromNames([
        'TestSessionTrustLifetime.test_advanced_mode_is_off_after_power_cycle',
        'TestSessionTrustLifetime.test_signer_dropped_by_power_cycle'], tests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    success = result.wasSuccessful() and not result.skipped
finally:
    owned[0].terminate()
    owned[0].wait()
    subprocess.Popen = original_popen
sys.exit(0 if success else 1)
