FROM kk715-stack06-agent1-corrective-full:local
COPY unittests/firmware/fsm.cpp /kkemu/unittests/firmware/fsm.cpp
COPY lib/firmware/ethereum.c /kkemu/lib/firmware/ethereum.c
RUN make -j4
