set -eu
cp /evidence/kkemu-${VARIANT} /tmp/kkemu
chmod +x /tmp/kkemu
mkdir /tmp/emulator-work
cd /tmp/emulator-work
/tmp/kkemu > /evidence/cointable-wire-emulator-${VARIANT}.log 2>&1 &
export PYTHONPATH=/audit-host
python3 /evidence/cointable-wire.py
