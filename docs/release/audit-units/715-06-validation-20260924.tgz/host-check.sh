#!/bin/sh
set -eu
cp /evidence/kkemu-${VARIANT} /tmp/kkemu
chmod +x /tmp/kkemu
mkdir /tmp/emulator-work
cd /tmp/emulator-work
/tmp/kkemu > /evidence/emulator-${VARIANT}.log 2>&1 &
export KK_TRANSPORT_MAIN=127.0.0.1:11044
export KK_TRANSPORT_DEBUG=127.0.0.1:11045
export KK_EMULATOR_BIN=/tmp/kkemu
export PYTHONPATH=/audit-host
cd /audit-host/tests
pytest -v --tb=short -p no:cacheprovider --junitxml=/evidence/host-${VARIANT}.xml
