#!/bin/sh
set -eu
python3 - <<'PY'
p='lib/board/messages.c'
s=open(p).read().replace('memzero(msg_tiny, sizeof(msg_tiny));', '/* negative control: retain tiny secret */')
open(p,'w').write(s)
if __import__('os').environ['VARIANT'] == 'full':
 p='lib/firmware/ethereum_contracts/zxliquidtx.c'
 s=open(p).read().replace('memzero(&node, sizeof(node));', '/* negative control: retain key */')
 open(p,'w').write(s)
PY
make -j4 firmware-unit
set +e
./bin/firmware-unit --gtest_filter=USBRX.TinyAcknowledgementDoesNotReusePreviousSecret --gtest_output=xml:/evidence/negative-tiny-${VARIANT}.xml
tiny_status=$?
key_status=1
if [ "$VARIANT" = full ]; then
 ./bin/firmware-unit --gtest_filter=Ethereum.LiquidityDerivationWipesRootAndPartialKeysOnEveryFailure --gtest_output=xml:/evidence/negative-key.xml
 key_status=$?
fi
set -e
test "$tiny_status" -ne 0
test "$key_status" -ne 0
echo 'Expected negative controls detected the removed protections'
