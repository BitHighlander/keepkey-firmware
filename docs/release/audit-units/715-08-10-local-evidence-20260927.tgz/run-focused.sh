#!/bin/sh
set -eu
mkdir -p /run-tests
cd /run-tests
/build/bin/kkemu > /evidence/emulator-positive.log 2>&1 &
EMU_PID=$!
trap 'kill "$EMU_PID"' EXIT
sleep 2
export KK_FORCE_UDP=1 KK_TRANSPORT_MAIN=127.0.0.1:11044 KK_TRANSPORT_DEBUG=127.0.0.1:11045
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/source/deps/python-keepkey:/source/deps/python-keepkey/tests
export FW_VERSION=7.15.0 KK_FIRMWARE_VARIANT=full
export KK_RELEASE_MISSING_CAPABILITIES=entropy-audit-budget,osmosis-wire-guards,hive-release-review,storage-v19-kdf,solana-lut-attestation
python3 -m pytest -v -p no:cacheprovider --tb=short /source/scripts/emulator/test_stack10_regressions.py /source/deps/python-keepkey/tests/test_msg_ethereum_signtx.py /source/deps/python-keepkey/tests/test_msg_ethereum_signtx_xfer.py /source/deps/python-keepkey/tests/test_msg_ethereum_erc20_uniswap_liquidity.py --junitxml=/evidence/positive-wire.xml > /evidence/positive-wire.log 2>&1
