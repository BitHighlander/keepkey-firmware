#!/bin/sh
set -eu
mkdir -p /run-host
cd /run-host
/build/bin/kkemu > /evidence/emulator-host.log 2>&1 &
EMU_PID=$!
trap 'kill "$EMU_PID"' EXIT
sleep 2
export KK_FORCE_UDP=1 KK_TRANSPORT_MAIN=127.0.0.1:11044 KK_TRANSPORT_DEBUG=127.0.0.1:11045
export PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/source/deps/python-keepkey:/source/deps/python-keepkey/tests
export FW_VERSION=7.15.0 KK_FIRMWARE_VARIANT=full KK_STACK07_FIRMWARE_VARIANT=full
export KK_RELEASE_MISSING_CAPABILITIES=entropy-audit-budget,osmosis-wire-guards,hive-release-review,storage-v19-kdf,solana-lut-attestation
export KK_REQUIRE_ERC7730_EVIDENCE=1 ERC7730_REGISTRY=/registry ERC7730_FIRMWARE_VALIDATOR=/build/bin/erc7730-validate
python3 -m pytest -v -p no:cacheprovider --tb=short /source/deps/python-keepkey/tests /source/scripts/emulator/test_stack07_regressions.py /source/scripts/emulator/test_stack10_regressions.py --junitxml=/evidence/host-full.xml > /evidence/host-full.log 2>&1
