from pathlib import Path
from xml.sax.saxutils import escape
import sys
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
import fitz

source = Path(sys.argv[1])
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='Audit', fontName='Helvetica', fontSize=8,
                         leading=10.5, spaceAfter=5, splitLongWords=True))
body = styles['Audit']
lines = source.read_text().splitlines()
story = []
i = 0
while i < len(lines):
    line = lines[i]
    if not line.strip():
        i += 1
        continue
    if line.startswith('|'):
        rows = []
        while i < len(lines) and lines[i].startswith('|'):
            cells = [x.strip() for x in lines[i].strip('|').split('|')]
            if not all(set(x) <= set('-: ') for x in cells):
                rows.append([Paragraph(escape(x.replace('`', '')), body) for x in cells])
            i += 1
        n = len(rows[0])
        widths = ([175, 348] if n == 2 else [95, 180, 248] if n == 3 else [523 / n] * n)
        if n == 3 and rows[0][0].text == 'Added':
            widths = [40, 40, 443]
        table = Table(rows, colWidths=widths, repeatRows=1, hAlign='LEFT')
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e7edf4')),
            ('GRID', (0, 0), (-1, -1), .3, colors.lightgrey),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LEFTPADDING', (0, 0), (-1, -1), 4),
            ('RIGHTPADDING', (0, 0), (-1, -1), 4)]))
        story.extend([table, Spacer(1, 8)])
        continue
    if line.startswith('#'):
        level = len(line) - len(line.lstrip('#'))
        story.append(Paragraph(escape(line.lstrip('# ')), styles['Heading1' if level == 1 else 'Heading2']))
        i += 1
        continue
    paragraph = []
    while i < len(lines) and lines[i].strip() and not lines[i].startswith(('#', '|')):
        paragraph.append(lines[i])
        i += 1
    story.append(Paragraph(escape(' '.join(paragraph).replace('`', '')), body))

def footer(canvas, doc):
    canvas.setFont('Helvetica', 7)
    canvas.drawString(36, 20, 'KeepKey 7.15 local audit | 2026-09-27 | No release approval')
    canvas.drawRightString(A4[0]-36, 20, str(doc.page))

pdf = source.with_suffix('.pdf')
SimpleDocTemplate(str(pdf), pagesize=A4, leftMargin=36, rightMargin=36,
                  topMargin=32, bottomMargin=34).build(story, onFirstPage=footer, onLaterPages=footer)
pages = Path('/private/tmp/kk715-stack10-evidence/report-pages') / source.stem
pages.mkdir(parents=True, exist_ok=True)
doc = fitz.open(pdf)
for n, page in enumerate(doc):
    page.get_pixmap(matrix=fitz.Matrix(1.2, 1.2)).save(pages / ('page-%d.png' % (n + 1)))
print(pdf, len(doc), 'pages')
