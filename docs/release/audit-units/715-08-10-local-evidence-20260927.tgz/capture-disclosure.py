import json
from pathlib import Path
from test_stack10_regressions import TestStack10Disclosure

case = TestStack10Disclosure('test_exact_raw_values_contract_and_counterparty')
case.setUp()
try:
    case.client.screenshot_dir = '/evidence/oled-max-approval'
    case.client.screenshot_id = 0
    Path(case.client.screenshot_dir).mkdir(exist_ok=True)
    original = case.client.debug.read_confirm_text
    def capture():
        text = original()
        case.client._capture_oled_after_settle()
        return text
    case.client.debug.read_confirm_text = capture
    response = case._signed(case._tx(True, (1 << 256) - 2))
    Path('/evidence/oled-max-approval/screens.json').write_text(json.dumps({
        'screens': case.screens, 'button_codes': case.button_codes,
        'signature_received': response.HasField('signature_r')}, indent=2))
finally:
    case.tearDown()
