import json
from pathlib import Path
from test_stack10_regressions import TestStack10Disclosure, types

t = TestStack10Disclosure('test_exact_raw_values_contract_and_counterparty')
results = []
t.setUp()
try:
    t.client.apply_policy('ShapeShift', 1)
    path = [0x8000002c, 0x8000003c, 0x80000001, 0, 0]
    baseline = None
    for mode in ('absent', 'explicit_empty'):
        tx = t._tx(value=b'\1', address_type=types.TRANSFER)
        tx.to_address_n.extend(path)
        tx.ClearField('to')
        if mode == 'absent':
            tx.ClearField('data_length')
            tx.ClearField('data_initial_chunk')
        else:
            tx.data_length = 0
            tx.data_initial_chunk = b''
        result = t._signed(tx)
        signature = (result.signature_r, result.signature_s)
        if baseline is None:
            baseline = signature
        assert signature == baseline
        item = dict(mode=mode, signed=True, matches_baseline=True, screens=t.screens)
        results.append(item)
        print(json.dumps(item), flush=True)
finally:
    t.tearDown()
    Path(__file__).with_name('native-compat-results.json').write_text(json.dumps(results, indent=2) + '\n')
