import json
from pathlib import Path
from test_stack10_regressions import TestStack10Disclosure, types, eth, proto

t = TestStack10Disclosure('test_exact_raw_values_contract_and_counterparty')
results = []
t.setUp()
try:
    t.client.apply_policy('ShapeShift', 1)
    path = [0x8000002c, 0x8000003c, 0x80000001, 0, 0]
    recipient = t.client.ethereum_get_address(path)
    for token, contract in [('known', bytes.fromhex('d0d6d6c5fe4a677d343cc433536bb717bae167dd')), ('unknown', b'\x42' * 20)]:
        for shape in ('canonical68', 'initial69', 'streamed69'):
            for advanced in (1, 0):
                t.client.apply_policy('AdvancedMode', advanced)
                tx = t._tx(contract=contract, recipient=recipient, address_type=types.TRANSFER)
                tx.to_address_n.extend(path)
                arguments = None
                if shape == 'initial69':
                    tx.data_initial_chunk += b'\0'
                    tx.data_length += 1
                if shape == 'streamed69':
                    tx.data_length += 1
                    arguments = b'\0'
                result, buttons, _, _ = t._walk(tx, arguments=arguments)
                item = dict(token=token, shape=shape, advanced=advanced,
                            response=type(result).__name__, signed=isinstance(result, eth.EthereumTxRequest) and result.HasField('signature_r'),
                            code=getattr(result, 'code', None), message=getattr(result, 'message', None),
                            buttons=buttons, screens=t.screens)
                results.append(item)
                print(json.dumps(item), flush=True)
    t.client.apply_policy('AdvancedMode', 1)
    for transfer in (False, True):
        for representation, value in [('absent', None), ('empty', b''), ('one_zero', b'\0'), ('padded_zero', b'\0' * 32), ('one', b'\1'), ('padded_one', b'\0' * 31 + b'\1')]:
            tx = t._tx(recipient=recipient, **({'address_type': types.TRANSFER} if transfer else {}))
            if transfer:
                tx.to_address_n.extend(path)
            if value is None:
                tx.ClearField('value')
            else:
                tx.value = value
            result, buttons, _, _ = t._walk(tx)
            item = dict(transfer=transfer, representation=representation,
                        response=type(result).__name__, signed=isinstance(result, eth.EthereumTxRequest) and result.HasField('signature_r'),
                        code=getattr(result, 'code', None), message=getattr(result, 'message', None),
                        buttons=buttons, screens=t.screens)
            results.append(item)
            print(json.dumps(item), flush=True)
finally:
    t.tearDown()
    Path(__file__).with_name('probe-results.json').write_text(json.dumps(results, indent=2) + '\n')
