# Block10 independent audit probes — 2026-09-28

Source directory: `/private/tmp/kk715-block10-review-20260928`.
Original source commit: `24a9b41a38c210c7feb733d92061ad72c77ba085`.
Docker base image: `7438e53933d4` (pinned firmware image).
Build directory: `/private/tmp/kk715-block10-audit-probe-20260928`.

Original build (source mounted read-only at `/root/keepkey-firmware`, build mounted at `/root/build`):

```sh
cmake -C /root/keepkey-firmware/cmake/caches/emulator.cmake /root/keepkey-firmware -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Debug -DCMAKE_COLOR_MAKEFILE=OFF
make -j4 kkemu
```

The original emulator binary is preserved as `kkemu-original24a9`; it was copied before rebuilding. `original-probe-results.json` records its independent wire probe results. `negative-junit.xml` and `negative.log` record the newly added regression failing against the original binary.

Fixed build and first native invocation:

```sh
make -j4 kkemu firmware-unit
./bin/firmware-unit --gtest_output=xml:/root/build/firmware-unit-fixed.xml
```

The first native invocation reused the original emulator's working directory and persistent `emulator.img`. It failed the recovery test's initial empty-storage precondition (668 pass, one failure), preserved in `fixed-build-native.log` / `firmware-unit-fixed.xml`. The native suite was then invoked from a new empty directory `/root/build/native-fresh`, preserving the old image and failed evidence:

```sh
/root/build/bin/firmware-unit --gtest_output=xml:/root/build/firmware-unit-fixed-fresh.xml
```

The fixed emulator runs from a separate writable `runtime-fixed` directory so it does not share its flash image with native tests. Emulator UDP ports are published only on localhost 11044/11045. Host wire commands use these environment values:

```sh
PYTHONPATH=deps/python-keepkey:deps/python-keepkey/tests:scripts/emulator
PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION=python
KK_FORCE_UDP=1
KK_TRANSPORT_MAIN=127.0.0.1:11044
KK_TRANSPORT_DEBUG=127.0.0.1:11045
KK_FIRMWARE_VARIANT=full
```

`KK_FORCE_UDP=1` prevents hardware autodetection. The pure-Python protobuf implementation supports the pinned generated message modules under host Python3.14.

Wire invocations under that environment:

```sh
python3 probe.py
python3 -m pytest -q scripts/emulator/test_stack10_regressions.py -k test_transfer_account_rejects_noncanonical_total_length --junitxml=negative-junit.xml
python3 -m pytest -q --disable-warnings scripts/emulator/test_stack10_regressions.py --junitxml=fixed-wire-junit.xml
python3 native_compat.py
```

The independent probe covers known ADT and unknown token account transfers with canonical68, initial69, and streamed69 calldata, with AdvancedMode on and off. It also covers omitted, empty, one-byte-zero, padded-zero, one, and padded-one native value fields in ordinary and account transfer modes. Original and fixed outputs are separately retained. The tracked new regression uses known DAI and unknown token contracts and additionally covers declared67/zero/absent lengths plus successful canonical retries after each refusal. `native_compat.py` proves native account transfers with absent calldata and explicitly empty calldata have identical review and signatures.
