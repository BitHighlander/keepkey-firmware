# Independent review of storage refusal closure

Reviewer: `/root/entropy_identity`. Candidate source:
`36d9f32f0daac85d3baa68996e0c59112dffbf74`.
Reviewed `fsm.c`, `fsm_msg_common.h`, `storage.c`, `storage.h`, the complete
new `IncompatibleStorage` fixture in `unittests/firmware/fsm.cpp`, and the
storage agent's source/control receipt and XML outcomes.

No actionable finding remains in the reviewed delta.

- Both storage lock flags remain distinct. Their only clearing operation is
  `storage_wipe()`. `storage_reset()` resets the shadow without clearing the
  flags. The existing commit backstop remains effective.
- Creation reaches `CHECK_NOT_INITIALIZED`, which now checks both flags before
  allowing the empty shadow to authorize a seed. Reset/Load retain the older
  BTC-specific failure code because their earlier guard still runs first.
- ChangePin, ChangeWipeCode, ApplySettings and ApplyPolicies reach the common
  refusal before user confirmation or shadow mutation. All direct commits in
  these handlers were traced. Authenticator Ping guards every recognized command
  before PIN/passphrase checks or its helper dispatch, including operations
  presented as reads that may re-encrypt stored data. Ordinary Ping remains
  available. The earlier manufacturing-model OTP branch is a different storage
  domain and does not alter the protected wallet sector or clear its flags.
- Recovery dry runs require initialization and therefore cannot operate on
  the reset shadow. Reset/recovery continuations require an armed ceremony;
  refused starts never arm one. U2F register/authenticate separately require
  initialized storage, preventing their counter path in either locked state.
- Confirmed WipeDevice is the deliberate escape. Declined wipe, Initialize and
  ordinary traffic preserve both flags and flash. The positive tests exercise
  post-wipe seed/settings persistence through the actual loader and reset/
  recovery start/cancel paths.
- The fixture derives flags from actual version bytes in emulated flash, not
  a test-only flag setter. It covers normal future versions 18 and 9999,
  current incompatible BTC, future BTC, and UINT32_MAX; current BTC is correctly
  excluded only from the BTC variant where it is supported. Assertions cover
  complete flash bytes, explicit failure, unconsumed confirmation, inactive
  setup, and unchanged shadow flags. No predecessor test assertion is weakened.
- Checked reported controls: full 30/30 positive, 9/30 expected baseline
  failures, 30/30 restored; BTC 24/24 positive, 8/24 expected baseline failures,
  24/24 restored. The misleading first overlay run is excluded because the
  archived logs show its object was not rebuilt. Final baseline builds record
  real recompilation and expected behavioral failures, not a build error.

This source/evidence review supports local software closure. Physical
power-cycle/power-fail and final root candidate integration remain separately
owned gates.
