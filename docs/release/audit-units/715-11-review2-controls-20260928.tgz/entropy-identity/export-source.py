import hashlib
import json
import pathlib
import shutil
import subprocess

root = pathlib.Path('/private/tmp/kk715-stack11-run3')
out = pathlib.Path('/private/tmp/kk715-stack11-entropy-source')
seed = pathlib.Path('/private/tmp/kk715-stack11-validator-source')
shutil.copytree(seed, out, symlinks=True)
manifest = {}
entries = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root).split(b'\0')
for entry in entries:
    if not entry:
        continue
    meta, raw = entry.split(b'\t', 1)
    mode, sha, stage = meta.decode().split()
    rel = raw.decode()
    if mode == '160000':
        manifest[rel] = {'gitlink': sha}
        continue
    src, dst = root / rel, out / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if src.is_symlink():
        manifest[rel] = {'symlink': str(src.readlink())}
        continue
    shutil.copy2(src, dst)
    manifest[rel] = {'sha256': hashlib.sha256(src.read_bytes()).hexdigest()}
for raw in subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=root).split(b'\0'):
    if not raw:
        continue
    rel = raw.decode()
    src, dst = root / rel, out / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    manifest[rel] = {'sha256': hashlib.sha256(src.read_bytes()).hexdigest()}
pathlib.Path(__file__).with_name('source-snapshot.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(f'Copied clean direct dependencies exported from pinned git objects, overlaid {len(manifest)} current paths into {out}')
