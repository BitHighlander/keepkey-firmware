import json
import pathlib
import shutil
import subprocess

evidence = pathlib.Path(__file__).resolve().parent
source = pathlib.Path('/private/tmp/kk715-stack11-run3')
baseline = evidence / 'baseline'
(baseline / 'lib/board').mkdir(parents=True, exist_ok=True)
(baseline / 'unittests/board').mkdir(parents=True, exist_ok=True)
old = subprocess.check_output(
    ['git', 'show', '8cd5561a241b7f5f5cb7068eb8bc3e2d30de166b:lib/board/keepkey_flash.c'],
    cwd=source)
(baseline / 'lib/board/keepkey_flash.c').write_bytes(old)
shutil.copyfile(source / 'unittests/board/hw_entropy_probe.c',
                baseline / 'unittests/board/hw_entropy_probe.c')
results = []
for variant in ('full', 'btc'):
    for state in ('fixed', 'baseline'):
        name = f'{variant}-{state}'
        build = evidence / f'build-{name}'
        configure = ['cmake', '-S', str(evidence), '-B', str(build),
                     '-DPROBE_BITCOIN_ONLY=' + ('ON' if variant == 'btc' else 'OFF')]
        if state == 'baseline':
            configure.append('-DPROBE_SOURCE=' + str(baseline / 'unittests/board/hw_entropy_probe.c'))
        with (evidence / f'{name}-build.log').open('w') as log:
            subprocess.run(configure, stdout=log, stderr=subprocess.STDOUT, check=True)
            subprocess.run(['cmake', '--build', str(build), '-j4'], stdout=log,
                           stderr=subprocess.STDOUT, check=True)
        xml = evidence / f'{name}.xml'
        with (evidence / f'{name}.log').open('w') as log:
            run = subprocess.run([str(build / 'entropy-unit'), '--gtest_output=xml:' + str(xml)],
                                 stdout=log, stderr=subprocess.STDOUT)
        expected = 1 if state == 'baseline' else 0
        if run.returncode != expected:
            raise SystemExit(f'{name}: expected exit {expected}, got {run.returncode}')
        results.append({'variant': variant, 'state': state,
                        'returncode': run.returncode, 'expected': expected,
                        'xml': str(xml), 'log': str(evidence / f'{name}.log')})
(evidence / 'entropy-controls.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
