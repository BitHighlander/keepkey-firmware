from __future__ import print_function
import json
import os
import shlex
import subprocess
import sys
import xml.etree.ElementTree as ET

build = os.path.abspath(sys.argv[1])
evidence = '/root/evidence'
source = '/root/keepkey-firmware'
variant = sys.argv[2]
out = os.path.join(evidence, 'crypto-controls-' + variant)
if not os.path.isdir(out):
    os.makedirs(out)

with open(os.path.join(build, 'compile_commands.json')) as handle:
    entries = json.load(handle)
with open(os.path.join(build, 'unittests/firmware/CMakeFiles/firmware-unit.dir/link.txt')) as handle:
    link = shlex.split(handle.read())
link_dir = os.path.join(build, 'unittests/firmware')
results = []

def run(state, binary, expected_failures):
    cwd = os.path.join(out, state + '-cwd')
    if not os.path.isdir(cwd):
        os.makedirs(cwd)
    xml = os.path.join(out, state + '.xml')
    with open(os.path.join(out, state + '.log'), 'w') as log:
        code = subprocess.call([binary, '--gtest_filter=CryptoCleanup.*',
                                '--gtest_output=xml:' + xml], cwd=cwd,
                               stdout=log, stderr=subprocess.STDOUT)
    root = ET.parse(xml).getroot()
    failures = int(root.attrib['failures'])
    if code != bool(expected_failures) or failures != expected_failures:
        raise RuntimeError('%s expected %d failures; exit %d, got %d' %
                           (state, expected_failures, code, failures))
    failed_names = [case.attrib['name'] for case in root.findall('.//testcase')
                    if case.find('failure') is not None]
    results.append({'state': state, 'exit': code, 'failures': failures,
                    'tests': int(root.attrib['tests']), 'failed': failed_names})

run('fixed', os.path.join(build, 'bin/firmware-unit'), 0)

for state, filename, expected in [('baseline-cleanup', 'fsm.c', 5),
                                  ('poisoned-recovery-byte', 'crypto.c', 1)]:
    entry = next(item for item in entries
                 if item['file'] == source + '/lib/firmware/' + filename)
    mutation_dir = os.path.join(out, state)
    if not os.path.isdir(mutation_dir):
        os.makedirs(mutation_dir)
    with open(entry['file']) as handle:
        original = handle.read()
    if filename == 'crypto.c':
        if original.count('uint8_t pby = 0;') != 1:
            raise RuntimeError('recovery-byte mutation does not match source')
        original = original.replace('uint8_t pby = 0;', 'uint8_t pby = 0xa5;')
    else:
        with open(os.path.join(evidence, 'baseline-crypto-header.h')) as handle:
            header = handle.read()
        with open(os.path.join(mutation_dir, 'fsm_msg_crypto.h'), 'w') as handle:
            handle.write(header)
    alternate = os.path.join(mutation_dir, filename)
    with open(alternate, 'w') as handle:
        handle.write(original)
    obj = os.path.join(mutation_dir, filename + '.o')
    command = shlex.split(entry['command'])
    command[command.index('-o') + 1] = obj
    command[command.index(entry['file'])] = alternate
    binary = os.path.join(mutation_dir, 'firmware-unit')
    command_link = list(link)
    command_link.insert(1, obj)
    command_link[command_link.index('-o') + 1] = binary
    with open(os.path.join(out, state + '-build.log'), 'w') as log:
        subprocess.check_call(command, cwd=entry['directory'], stdout=log,
                              stderr=subprocess.STDOUT)
        subprocess.check_call(command_link, cwd=link_dir, stdout=log,
                              stderr=subprocess.STDOUT)
    run(state, binary, expected)

with open(os.path.join(out, 'results.json'), 'w') as handle:
    json.dump(results, handle, indent=2)
    handle.write('\n')
print(json.dumps(results, indent=2))
