#!/bin/sh
set -eu
cmake -C /root/keepkey-firmware/cmake/caches/emulator.cmake /root/keepkey-firmware \
  -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ \
  -DCMAKE_BUILD_TYPE=Debug -DCMAKE_EXPORT_COMPILE_COMMANDS=ON \
  -DKK_BITCOIN_ONLY="$1"
cmake --build . -- -j6 board-unit firmware-unit
./bin/board-unit --gtest_filter='HardwareEntropy.*' --gtest_output=xml:entropy.xml
./bin/firmware-unit --gtest_filter='CryptoCleanup.*' --gtest_output=xml:crypto.xml
