/* Unused board dependencies must never be reached by the entropy entry point. */
#include <stdint.h>
#include <stdlib.h>
#include "keepkey/board/check_bootloader.h"
uint8_t* emulator_flash_base;
BootloaderKind get_bootloaderKind(void) { abort(); }
