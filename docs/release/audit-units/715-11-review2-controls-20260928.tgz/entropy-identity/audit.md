# Block 11 review 2: entropy and identity cleanup

Baseline: `8cd5561a241b7f5f5cb7068eb8bc3e2d30de166b`, PR 877.
Assigned comments: 4118361277 and 4118361337.

## Source findings and scope

4118361277 is reproduced by source trace: privileged firmware calls
`flash_collectHWEntropy()` before board, DRBG and storage initialization
(`tools/firmware/keepkey_main.c`). Previously a failed checked first draw left
OTP unlocked, then unconditionally copied erased OTP into the entropy buffer
and returned to startup. The repair clears temporary and global entropy and
calls raw `shutdown()`. The ARM routine disables interrupts, wipes RAM and
halts without using the display or timer (`tools/firmware/startup.s`). A later
healthy boot can still provision the unchanged unlocked OTP block. Existing
locked OTP and the documented fixed unsigned-firmware entropy policy retain
their behavior.

The class audit also checks programming, readback and lock persistence. The
OTP API's bool failures are bounds checks, which current constant arguments
cannot trigger; its hardware programming helpers nevertheless return true
without proving successful programming. The repair reads back and compares all
32 drawn bytes before attempting the irreversible lock, verifies the actual
lock state, and checks reads from an existing locked block. Silent/partial
programming, a failed read or a dropped lock cannot return usable entropy.

4118361337 correctly identifies missing handler-local cleanup. Its stated
lifetime needs qualification: the baseline's `keepkey_after_message_dispatch()`
already clears the shared derived node after normal wire dispatch. The key was
nevertheless retained through response output and layout, and direct handler
calls lacked that dispatch cleanup. The repair scrubs before both success and
signing-failure output. `fsm_getDerivedNode()` already scrubs entry and all
failure-after-write paths; its NULL return gives the caller no key pointer.

The equivalent handler in the same file, `CipherKeyValue`, also retained its
derived node on consent cancellation and successful encryption/decryption.
It now clears the node after the HMAC operation or on cancellation, and clears
the derived HMAC material and both AES context variants before sending output.
Identity hash/path and generic-signing digest scratch are also cleared after
their last use. Fingerprints and challenge digests are not private-key material.

An additional falsification finding is fixed in `crypto.c`: the generic
identity-signing path can use Ed25519, whose signing helper does not populate
the ECDSA recovery byte. The previous uninitialized `pby` could influence the
first response-signature byte. Initializing it to zero makes this non-ECDSA
prefix deterministic while preserving ECDSA's helper-supplied recovery value.

## Security closure matrix

| Finding/state and origin | Observer, variants and phase | Allowed / forbidden output | Entry path and assertion | Falsification |
| --- | --- | --- | --- | --- |
| 4118361277: random OTP contribution, first privileged boot | DRBG/PIN KDF consumers; full and BTC device branch; startup before board initialization | Healthy device ID + OTP permitted; erased/partial unlocked OTP after rejected draw and continuation into consumers forbidden | Actual `flash_collectHWEntropy(true)` compiled from production source with only hardware/RNG/halt dependencies replaced: healthy draw writes/locks/reads exactly once; failed draw halts without read/write/lock, leaves OTP unchanged, clears local/global buffers and never returns | Reject a draw containing deliberately nonzero bytes; repeat against both erased `0xff` and partially programmed `0x19` OTP. Baseline mutation must fail these assertions |
| 4118361277: existing locked OTP and unsigned policy | Same variants; later boot / unsigned startup | Existing locked bytes retained without needing a new draw; unsigned firmware remains fixed `0x3c` | Actual entry function: locked OTP reads once without a draw even when a fresh draw would fail; unprivileged input performs no hardware entropy operations | Attempt fresh-draw failure in the locked path and verify it cannot replace stored bytes |
| 4118361337: identity private key, shared derived HDNode | Later request or memory observer; full/BTC native handler; success, failed signing, failed derivation, cancellation | Approved signature/address/public key permitted; retained derived key after completion forbidden | Real direct handler and installed USB receive callback. Independent HTTPS/SSH/GPG/signify signature/public-key vectors preserved. Entire node is zero after success, invalid GPG digest lengths 0/31/33 and failed derivation. Cancellation produces Failure | Alternate protocol/curve, missing visual challenge, direct call bypassing dispatch cleanup, consecutive success/failure/cancel; baseline handler mutation must fail direct cleanup cases even where wire dispatch provides later cleanup |
| Adjacent CipherKeyValue derived key and derived AES material | Same variants; approval cancellation / encrypt / decrypt | Exact requested cipher result permitted; retained HDNode forbidden | Real direct handler and USB callback; fixed independent encrypt/decrypt vectors, both cancellation paths, zero node at return | Both cryptographic directions and direct invocation; baseline node-cleanup mutation must fail. HMAC/AES stack wiping additionally source-reviewed; stack bytes are not read after lifetime |
| OTP programming/readback/lock trust | DRBG/PIN consumers; device branch full/BTC, first and later boot | Return only after exact fresh readback and persistent lock, or successful read of an existing lock | Actual entry probe rejects failed/dropped/partial writes, failed reads that already populated output, rejected/dropped locks and failed existing-block reads; global entropy zero and no return; bad readback prevents lock | API return true despite dropped programming or lock; partially filled output before false read result |
| Generic Ed25519 recovery-byte output | Host; full/BTC direct and USB signing | Deterministic prefix31 and independently verifiable signature; uninitialized stack byte forbidden | Fixed public key plus independently calculated Bitcoin-envelope SHA256d digest and Ed25519 verification; prefix31 assertion | Compile isolated `pby=0xa5` mutation; only the intended signature-prefix test fails, while cryptographic verification still passes |

The native hardware probe is explicitly a substitute for hardware dependencies,
not a device execution. Device shutdown assembly and boot call ordering are
source evidence pending the final ARM link. OTP programming electrical faults,
power loss, validation of historically programmed OTP contents, and physical
memory inspection remain outside these targeted tests.
The key-retention assertion covers the shared `fsm_derived_node` scratch.
Authorized session seed and BIP32 ancestor caches keep their existing lifetime;
this repair does not claim that all wallet key material disappears per request.

## Test registration and oracle provenance

`unittests/board/CMakeLists.txt` registers `hw_entropy.cpp` and its C probe.
The probe compiles the device branch of the real `keepkey_flash.c`; only that
translation unit receives minimal libopencm3 register headers. No test hook or
conditional enters the production implementation.

`unittests/firmware/CMakeLists.txt` registers `crypto_cleanup.cpp` unconditionally
for full and BTC native suites. The existing confirmation test driver is
extended to read real encoded output frames from its UDP client. It clears
stale outbound frames before each request. Tests do not read the shared frame
arena after dispatch, because the transport intentionally wipes that arena.

Signature/ciphertext vectors and the mnemonic come from the pinned dependency's
`tests/device_tests/test_msg_signidentity.py` and
`tests/device_tests/test_msg_cipherkeyvalue.py`. These are independent constants,
not values computed from a forbidden production output or from the handler
under test.

The first test run exposed a harness policy contradiction: Trezor's upstream
Signify vector assumes a specialized Signify handler absent from this KeepKey
baseline. KeepKey supports SSH/GPG special cases and otherwise signs a generic
Bitcoin message envelope. The corrected generic Ed25519 case retains the fixed
public-key oracle and verifies the signature against independently generated
hash `0f50514d5786a6e938f9fb1c5c76c3ccd2af39aa6ff3b885a93fefa77788aa04`.
The failing initial result is retained in `docker-full.log`; it is not reported
as a product signature regression. Other imported HTTPS/SSH/GPG/cipher vectors
passed unchanged.

## Status

Implementation, targeted/adversarial software verification and source audit:
complete for the owned delta, committed by root in
`36d9f32f0daac85d3baa68996e0c59112dffbf74`.

| Check | Full | BTC |
| --- | --- | --- |
| HardwareEntropy fixed | 7/7 pass | 7/7 pass |
| Original hardware-entropy source control | 5/7 fail as expected | 5/7 fail as expected |
| CryptoCleanup fixed, real handler + USB | 7/7 pass | 7/7 pass |
| Original crypto-header cleanup control | 5/7 fail as expected | 5/7 fail as expected |
| Poisoned recovery-byte control | 1/7 fails as expected | 1/7 fails as expected |

`run-entropy-controls.py` builds the actual device entry probe with pinned clean
googletest and the pinned memzero implementation on macOS; the normal full
Docker board suite also executes all seven entry-probe tests. Crypto controls
use pinned Docker image `7438e53933d4`, actual native firmware objects, and
separate pristine working directories. Mutant objects are compiled and relinked
into separate binaries; neither shared source nor existing build objects are
reverted. JSON/XML/logs record exact failures, rather than accepting any nonzero
exit. The fixed assertions pass before each mutation. Earlier partial source
snapshot builds that lacked a nested token dependency are preparatory failures,
not verification evidence.

Final formatting changes are semantic no-ops; the root owns final integrated
native/wire/ARM/CI qualification of the containing commit. External review,
physical device work and release acceptance remain separate and unclaimed here.
