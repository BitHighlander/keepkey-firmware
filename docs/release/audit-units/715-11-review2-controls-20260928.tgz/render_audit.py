#!/usr/bin/env python3
"""Render a small Markdown audit report as a paginated PDF.

Usage: render_audit.py INPUT.md OUTPUT.pdf [--title TITLE] [--page-size A4|letter]
Supports headings, paragraphs, lists, simple pipe tables and fenced code.
Needs reportlab; optional PyMuPDF reports the resulting page count.
"""

from __future__ import annotations

import argparse
from html import escape
from pathlib import Path
import re

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4, letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, Frame, LongTable, PageBreak, PageTemplate, Paragraph,
    Spacer, TableStyle,
)


def fonts() -> tuple[str, str, str, str]:
    candidates = (
        (
            Path('/System/Library/Fonts/Supplemental'),
            ('Arial.ttf', 'Arial Bold.ttf', 'Arial Italic.ttf', 'Courier New.ttf'),
        ),
        (
            Path('/usr/share/fonts/truetype/dejavu'),
            ('DejaVuSans.ttf', 'DejaVuSans-Bold.ttf',
             'DejaVuSans-Oblique.ttf', 'DejaVuSansMono.ttf'),
        ),
    )
    for directory, names in candidates:
        if all((directory / name).is_file() for name in names):
            face_names = ('AuditSans', 'AuditSans-Bold', 'AuditSans-Italic',
                          'AuditMono')
            for name, file_name in zip(face_names, names):
                pdfmetrics.registerFont(TTFont(name, str(directory / file_name)))
            pdfmetrics.registerFontFamily(
                'AuditSans', normal='AuditSans', bold='AuditSans-Bold',
                italic='AuditSans-Italic', boldItalic='AuditSans-Bold',
            )
            return face_names
    return ('Helvetica', 'Helvetica-Bold', 'Helvetica-Oblique', 'Courier')


REGULAR, BOLD, ITALIC, MONO = fonts()
INK = colors.HexColor('#18232D')
MUTED = colors.HexColor('#536371')
LINE = colors.HexColor('#CFD7DE')
TABLE_HEAD = colors.HexColor('#EAF0F5')


def inline(text: str, font_size: float = 9.2) -> str:
    """Convert supported inline Markdown without letting raw XML through."""
    tokens = re.compile(r'(`[^`]+`|\[[^\]]+\]\([^\)]+\)|\*\*.+?\*\*|(?<!\*)\*[^*]+\*(?!\*))')
    parts: list[str] = []
    for part in tokens.split(text):
        if part.startswith('`') and part.endswith('`'):
            parts.append(f'<font name="{MONO}" size="{font_size * .91:.2f}">'
                         f'{escape(part[1:-1])}</font>')
        elif part.startswith('**') and part.endswith('**'):
            parts.append('<b>' + inline(part[2:-2], font_size) + '</b>')
        elif part.startswith('*') and part.endswith('*'):
            parts.append('<i>' + inline(part[1:-1], font_size) + '</i>')
        elif (match := re.fullmatch(r'\[([^\]]+)\]\(([^\)]+)\)', part)):
            label, target = match.groups()
            if target.startswith(('https://', 'http://')):
                parts.append(f'<link href="{escape(target, quote=True)}" '
                             f'color="#234C70">{inline(label, font_size)}</link>')
            else:
                parts.append(inline(label, font_size))
        else:
            parts.append(escape(part).replace('&lt;br&gt;', '<br/>')
                         .replace('&lt;br/&gt;', '<br/>'))
    return ''.join(parts)


def styles() -> dict[str, ParagraphStyle]:
    base = ParagraphStyle(
        'Body', fontName=REGULAR, fontSize=9.2, leading=12.2,
        textColor=INK, alignment=TA_LEFT, spaceAfter=6.0,
        splitLongWords=1, allowWidows=0, allowOrphans=0,
    )
    result = {'body': base}
    for level, size, before, after in (
        (1, 19, 0, 13), (2, 12.1, 12, 6),
        (3, 10.5, 9, 5), (4, 9.5, 7, 4),
    ):
        result[f'h{level}'] = ParagraphStyle(
            f'H{level}', parent=base, fontName=BOLD, fontSize=size,
            leading=size * 1.22, spaceBefore=before, spaceAfter=after,
            keepWithNext=1,
        )
    result['table'] = ParagraphStyle(
        'TableCell', parent=base, fontSize=8.0, leading=10.5,
        spaceAfter=0, allowWidows=1, allowOrphans=1,
    )
    result['table_head'] = ParagraphStyle(
        'TableHeader', parent=result['table'], fontName=BOLD,
    )
    result['list'] = ParagraphStyle(
        'List', parent=base, leftIndent=13, bulletIndent=0,
        spaceAfter=4, bulletFontName=REGULAR, bulletFontSize=8.4,
    )
    result['code'] = ParagraphStyle(
        'Code', parent=base, fontName=MONO, fontSize=7.8, leading=10.2,
        leftIndent=8, rightIndent=8, borderPadding=7,
        backColor=colors.HexColor('#F3F5F7'), spaceBefore=3, spaceAfter=8,
        allowWidows=1, allowOrphans=1,
    )
    return result


def cells(line: str) -> list[str]:
    line = line.strip().strip('|')
    return [cell.strip().replace(r'\|', '|')
            for cell in re.split(r'(?<!\\)\|', line)]


def table_separator(line: str) -> bool:
    row = cells(line)
    return len(row) > 1 and all(re.fullmatch(r':?-{3,}:?', cell) for cell in row)


def column_widths(rows: list[list[str]], width: float) -> list[float]:
    count = len(rows[0])
    if count == 1:
        return [width]
    weights = []
    for column in range(count):
        lengths = sorted(len(row[column]) for row in rows)
        typical = lengths[(len(lengths) * 3) // 4]
        # A hash/path must wrap instead of taking the entire page width.
        weight = max(7, min(72, typical)) ** .65
        if all(re.fullmatch(r'[\d.,+%/ −–-]+', row[column])
               for row in rows[1:] if row[column]):
            weight = 2.0
        weights.append(weight)
    minimum = min(60, width / (count * 2.1))
    available = width - count * minimum
    total = sum(weights)
    return [minimum + available * item / total for item in weights]


def make_table(rows: list[list[str]], width: float,
               sheet: dict[str, ParagraphStyle]) -> LongTable:
    count = len(rows[0])
    rows = [(row + [''] * count)[:count] for row in rows]
    data = [
        [Paragraph(inline(cell, 8.0), sheet['table_head' if index == 0 else 'table'])
         for cell in row]
        for index, row in enumerate(rows)
    ]
    table = LongTable(
        data, colWidths=column_widths(rows, width), repeatRows=1,
        hAlign='LEFT', splitByRow=1, splitInRow=1, spaceBefore=3, spaceAfter=9,
    )
    table.setStyle(TableStyle([
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEAD),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1),
         [colors.white, colors.HexColor('#F8FAFC')]),
        ('LINEBELOW', (0, 0), (-1, 0), .6, LINE),
        ('LINEBELOW', (0, 1), (-1, -1), .25, LINE),
        ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ('TOPPADDING', (0, 0), (-1, -1), 5),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ]))
    return table


def parse(markdown: str, width: float) -> list:
    sheet = styles()
    lines = markdown.splitlines()
    story = []
    index = 0
    while index < len(lines):
        line = lines[index].strip()
        if not line:
            index += 1
            continue
        if line in ('<!-- pagebreak -->', '\\newpage'):
            story.append(PageBreak())
            index += 1
            continue
        if line.startswith('```'):
            index += 1
            block = []
            while index < len(lines) and not lines[index].lstrip().startswith('```'):
                block.append(escape(lines[index]).replace('  ', '&nbsp; '))
                index += 1
            story.append(Paragraph('<br/>'.join(block) or ' ', sheet['code']))
            index += 1
            continue
        if index + 1 < len(lines) and table_separator(lines[index + 1]):
            rows = [cells(line)]
            index += 2
            while index < len(lines) and '|' in lines[index] and lines[index].strip():
                rows.append(cells(lines[index]))
                index += 1
            story.append(make_table(rows, width, sheet))
            continue
        if (heading := re.match(r'^(#{1,6})\s+(.*)$', line)):
            style = sheet[f'h{min(len(heading.group(1)), 4)}']
            story.append(Paragraph(inline(heading.group(2), style.fontSize), style))
            index += 1
            continue
        if re.fullmatch(r'[-*_]{3,}', line):
            story.append(Spacer(1, 5))
            index += 1
            continue
        if (item := re.match(r'^([-*+] |\d+\. )(.*)$', line)):
            bullet = item.group(1).strip()
            bullet = '•' if bullet in '-*+' else bullet
            text = [item.group(2)]
            index += 1
            while (index < len(lines) and lines[index].strip()
                   and lines[index][:1].isspace()
                   and not re.match(r'^\s*[-*+] ', lines[index])):
                text.append(lines[index].strip())
                index += 1
            story.append(Paragraph(inline(' '.join(text)), sheet['list'],
                                   bulletText=bullet))
            continue
        text = [line]
        index += 1
        while index < len(lines) and lines[index].strip():
            following = lines[index].strip()
            if (following.startswith(('#', '```', '<!-- pagebreak'))
                    or re.match(r'^([-*+] |\d+\. )', following)
                    or (index + 1 < len(lines) and table_separator(lines[index + 1]))):
                break
            text.append(following)
            index += 1
        story.append(Paragraph(inline(' '.join(text)), sheet['body']))
    return story


def render(source: Path, destination: Path, title: str | None,
           page_size: tuple[float, float]) -> None:
    markdown = source.read_text(encoding='utf-8')
    heading = re.search(r'^#\s+(.+)$', markdown, re.MULTILINE)
    title = title or (heading.group(1) if heading else source.stem)
    destination.parent.mkdir(parents=True, exist_ok=True)
    page_width, page_height = page_size
    margin = 43
    document = BaseDocTemplate(
        str(destination), pagesize=page_size,
        leftMargin=margin, rightMargin=margin, topMargin=48, bottomMargin=43,
        title=title, author='KeepKey',
    )
    frame = Frame(
        document.leftMargin, document.bottomMargin,
        document.width, document.height, leftPadding=0, rightPadding=0,
        topPadding=0, bottomPadding=0, id='body',
    )

    def page(canvas, doc):
        canvas.saveState()
        canvas.setStrokeColor(LINE)
        canvas.setLineWidth(.4)
        canvas.line(margin, 31, page_width - margin, 31)
        canvas.setFillColor(MUTED)
        canvas.setFont(REGULAR, 7)
        running = title
        while pdfmetrics.stringWidth(running, REGULAR, 7) > document.width - 80:
            running = running[:-2]
        if running != title:
            running = running.rstrip() + '…'
        canvas.drawString(margin, 20, running)
        canvas.drawRightString(page_width - margin, 20, f'Page {doc.page}')
        if doc.page > 1:
            canvas.setFont(BOLD, 7.3)
            canvas.drawString(margin, page_height - 29, 'AUDIT REPORT')
            canvas.setStrokeColor(LINE)
            canvas.line(margin, page_height - 35, page_width - margin, page_height - 35)
        canvas.restoreState()

    document.addPageTemplates(PageTemplate(id='audit', frames=frame, onPage=page))
    document.build(parse(markdown, document.width))
    try:
        import pymupdf
        with pymupdf.open(destination) as pdf:
            print(f'{destination}: {len(pdf)} pages')
    except ImportError:
        print(destination)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--title')
    parser.add_argument('--page-size', choices=('A4', 'letter'), default='A4')
    options = parser.parse_args()
    render(options.input, options.output, options.title,
           A4 if options.page_size == 'A4' else letter)


if __name__ == '__main__':
    main()
