from pathlib import Path
import json
fw=Path('/Users/highlander/WebstormProjects/keepkey-stack/projects/keepkey-firmware/docs/release')
e=Path('/private/tmp/kk715-stack11-round3-evidence')
entry=(e/'ledger-entry.md').read_text()
owner=fw/'audit-claims/715-11/OWNER.md'
text=owner.read_text()
if entry not in text: owner.write_text(text.rstrip()+'\n\n'+entry+'\n')
master=fw/'MASTER-AUDIT-TEMPLATE.md'
text=master.read_text()
anchor='## 7.15 audit progress (not release approval)\n'
assert anchor in text
if entry not in text: master.write_text(text.replace(anchor,anchor+'\n'+entry+'\n',1))
(fw/'audit-claims/715-11/review-budget-20260928.json').write_text((e/'review-budget.json').read_text())
print('Updated Block 11 claim, budget, and canonical progress ledger.')
