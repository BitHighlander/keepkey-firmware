# Independent remediation review: entropy and identity

Reviewer: `/root/storage_guards`. Reviewed base:
`f0977b81d3393e4fbb181433c77091c07f61e14c`, with current uncommitted remediation.
Exact UTC time and inspected source hashes are in the adjacent JSON receipt.

**Source review conclusion: no concrete actionable defect found.** This is a
review of the remediation and relevant callers/consumers; final integrated
tests, ARM/resource gates and external/release acceptance remain root-owned.

- Traced privileged startup through `flash_collectHWEntropy()` before privilege
  drop, board setup and DRBG initialization. The raw ARM shutdown routine
  disables interrupts, wipes SRAM and registers, and halts without relying on
  an initialized screen, timer or call-stack return. The declaration is
  noreturn. Failed draws clear both temporary and global entropy and perform
  no OTP write/lock/read before shutdown.
- Read the actual OTP wrappers. Their success values validate bounds rather
  than programming pulses, so comparing readback before locking and checking
  the physical lock byte closes an actual adjacent failure path. Write,
  readback and lock errors all fail closed. Already locked OTP performs no
  new draw; unsigned firmware retains its explicit fixed-entropy policy.
- Reviewed the hardware probe substitutions. It compiles the production device
  branch; hardware functions and halt are substituted with observable state.
  Local-stack zero assertions happen during the substituted shutdown while
  the buffer remains alive. Fault controls cover rejected, dropped and partial
  writes; rejected read; rejected/dropped lock; and rejected read of an already
  locked block. CMake registers both probe and tests without a hidden skip.
- Inspected all `fsm_msg_crypto.h` derivation paths and the shared derivation
  helper. Every path after a successful derivation now scrubs before returning
  or sending a response. Null derivation returns are already scrubbed by the
  helper. Signature/address/public-key output is copied before the node is
  wiped. Cipher cancellation, encryption and decryption scrub the node; HMAC
  scratch and AES contexts are cleared after their last use.
- Checked `cryptoMessageSign()` against pinned `hdnode_sign_digest()` and
  `hdnode_sign()`: Ed25519 never assigns the ECDSA recovery-byte pointer.
  Initializing it to zero prevents an uninitialized envelope byte while ECDSA
  continues to supply its own identifier. Independently reconstructed the
  generic Bitcoin-message envelope digest with Python hashlib; it exactly
  matches `0f50514d5786a6e938f9fb1c5c76c3ccd2af39aa6ff3b885a93fefa77788aa04`
  asserted by the test. The generic Signify-name branch correctly preserves
  existing KeepKey behavior rather than assuming Trezor's special protocol.
- Tests use real USB output frames and independent expected public keys,
  signatures and ciphertext. Direct-handler tests independently catch retained
  node state that the later wire-dispatch blanket scrub would conceal. The UDP
  helper drains stale responses before each request. Existing confirmation
  queue counts are preserved; storage tests independently passed against it.

Inspected runtime evidence: hardware probes pass7/7 in each full/BTC variant;
original source produces5/7 expected failures in each. The previous crypto
vector mismatch is explicitly excluded from passing evidence. Final crypto
positive/cleanup-baseline controls are being completed by the owner. Requested
a deterministic poisoned-recovery-byte mutation as an independent check of
the new generic Ed25519 prefix assertion, since uninitialized stack bytes can
coincidentally be zero. This is a verification control, not a new production
finding.

Physical OTP programming/power-loss qualification, historically programmed
entropy quality and physical memory inspection remain outside native probe
evidence. No test or production change was made during this independent review.
