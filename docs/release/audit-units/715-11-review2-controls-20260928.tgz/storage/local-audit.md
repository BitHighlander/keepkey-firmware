# Storage refusal remediation — block 11 round 3 candidate

Reviewed baseline: `8cd5561a241b7f5f5cb7068eb8bc3e2d30de166b`.
Findings: `4118361256`, `4118361320` (one root cause).
Owner: `/root/storage_guards`.

## Contract and scope

| State/value | Origin | Observer/phase | Variants | Allowed | Forbidden | Equivalent representations |
| --- | --- | --- | --- | --- | --- | --- |
| Preserved wallet flash | Active sector with unsupported version | Host wallet creation or persistent settings request | Full/BTC | Explicit failure before confirmation or staging; unchanged flash; explicit confirmed device wipe | Success for unpersisted change, creation of transient seed, implicit wipe | Newer normal version 18, highest normal version 9999, incompatible BTC version, future BTC version, UINT32_MAX |
| Reset storage shadow | Loader refuses unsupported format | Reset/Recovery/Load and settings handlers | Full/BTC | Uninitialized state until explicit wipe, then ordinary persistence | Treating empty RAM shadow as permission to replace preserved wallet | ResetDevice, LoadDevice, RecoveryDevice, ChangePin, ChangeWipeCode, ApplySettings, ApplyPolicies |
| Authenticator storage | Same refused wallet sector | Authenticator commands carried by Ping | Full/BTC | Refusal before credential/prompt/storage work | Acknowledging unpersisted authenticator writes | All five authenticator command prefixes; reads may re-encrypt and commit |
| Explicit wipe | User confirms WipeDevice | Wipe handler, subsequent creation/settings and reboot | Full/BTC | Clear both locks, wipe, persist subsequent load/settings | Clearing lock on declined wipe, Initialize, ordinary Ping or failed creation | Confirmed and declined wipe, read-only traffic, stale EntropyAck and CharacterAck |

## Implementation

`CHECK_STORAGE_WRITABLE` checks both normal-format and bitcoin-only locks;
`CHECK_NOT_INITIALIZED` invokes it before permitting seed creation. All four
existing persistent-settings guards invoke the same macro. The authenticator
branch in Ping now uses it too. Existing BTC-specific Load/Reset failure codes
are retained. Explicit WipeDevice remains available.

The storage commit backstop remains unchanged. API documentation now states
that both lock flags must be checked. `storage_isBitcoinOnlyLocked()` continues
to describe only incompatible BTC-band storage; it is not repurposed to hide
the distinct normal-format lock.

## Adjacent consumer audit

- Traced every firmware `storage_commit()` caller. Setup starts pass through
  the common creation guard; continuations require an armed setup ceremony.
- All four settings handlers can otherwise change RAM then report success
  despite the commit backstop. Both lock types are checked before confirmation.
- Authenticator Ping was an additional reachable same-class path: notably
  wipeAuthData could acknowledge success although its storage commit was
  blocked. All five auth prefixes now refuse consistently. Ordinary Ping is
  still available. Transport cleanup wipes the decoded credential buffer after
  early handler returns (`lib/board/messages.c:dispatch`).
- U2F's counter write requires a stored U2F root. Unsupported-format loading
  resets that root, so this path is unreachable in either locked state.
- Root-seed cache persistence requires an existing mnemonic/node and decrypted
  secret state, also absent after refused loading.
- Session/PIN internal writes retain the flash backstop; they do not produce a
  host claim that a new seed or setting was persisted.
- `WipeDevice` calls `storage_wipe()` only after explicit confirmation; that
  function clears both flags. Cancelled wipe preserves the stored bytes.

## Executable checks

Existing registered `unittests/firmware/fsm.cpp` gains the parameterized
`FutureFormats/IncompatibleStorage` fixture, with real flash loading and actual
USB receive/decoder/handler dispatch. It has six test identities, instantiated
for five full-build versions and four BTC-build versions. The current BTC
version is intentionally excluded only from BTC firmware because it is
supported there; current-format post-wipe loading is exercised positively.

Tests assert explicit failure codes, no consumed confirmation, no armed setup,
no initialized wallet, no PIN/settings changes, and byte-for-byte preservation
of the entire emulated flash. Positive controls cover ordinary Ping/Initialize,
confirmed wipe, persistent imported seed and label across storage reloading,
and reset/recovery starts followed by cancellation. Dry-run recovery and stale
continuations are rejected without persistence. Declined wipe retains locks
even after reloading.

## Executed evidence and falsification

Pinned image `7438e53933d4`, Debug emulator full/BTC, DEBUG_LINK enabled;
`CMAKE_EXPORT_COMPILE_COMMANDS=ON`. Integrated base is
`f0977b81d3393e4fbb181433c77091c07f61e14c`, after accepted block10 refresh. Its
FSM guard sources match reviewed baseline 8cd exactly before this remediation.

| Variant | Corrected candidate | Original guard negative control | Restored candidate |
| --- | --- | --- | --- |
| Full | 30/30 pass | 9/30 fail, as expected | 30/30 pass |
| BTC | 24/24 pass | 8/24 fail, as expected | 24/24 pass |

The baseline runs substitute only saved 8cd `fsm.c` and `fsm_msg_common.h`
through read-only Docker mounts; shared production files were never reverted.
Creation/settings fail for normal-band versions18 and9999. Authenticator
commands fail across all incompatible versions (five full/four BTC). All
read-only, declined-wipe and post-wipe neighboring controls pass even on the
baseline. Each baseline process exits1 with its expected named GoogleTest
failures, rather than failing compilation or crashing.

The first overlay attempt used `make -W`, which did not rebuild the FSM object
through this old recursive CMake generator. Its passing output is explicitly
excluded from negative evidence (`*-overlay-not-recompiled.log`). The final
baseline and restoration remove only the generated FSM object and prove actual
recompilation in their build logs. This caught a stale-build harness failure
before attributing its silence to the original source.

The separate falsification pass tried the highest normal format, incompatible
BTC formats through UINT32_MAX, authenticator Ping prefixes, stale entropy and
recovery continuations, dry-run recovery, Initialize, ordinary Ping and declined
wipe. Flash remains unchanged and setup inactive for every refused path.
Confirmed wipe restores ordinary load/settings persistence and setup starts.
The expected behavior is derived from preserved flash bytes and independent
failure/confirmation assertions, not a helper returning the same classification.

Raw XML, logs, source hashes, dependency identities and exact failed test names
are in `evidence.json` and the adjacent artifacts. No tests are disabled or
skipped. Format20 and `git diff --check` pass. The existing CMake source list
already registers `fsm.cpp`; no test registration or prior assertions were
removed. Software reloads exercise storage persistence, while physical device
power-cycle and power-fail acceptance remain release-only work.

Both build directories also provide `kkemu`, `firmware-unit`, `board-unit` and
`crypto-unit` for root's final integrated validation. A subsequent independent
identity-agent change to `crypto.c`/`crypto_cleanup.cpp` does not affect these
storage paths; binaries were refreshed for that change without claiming the
carried storage evidence as a new exact-final-tree execution.
