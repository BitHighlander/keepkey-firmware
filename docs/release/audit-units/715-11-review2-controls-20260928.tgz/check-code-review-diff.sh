#!/bin/sh
# Fail before a firmware-code Copilot request if the proposed PR diff is a receipt.
set -eu

if [ "$#" -ne 2 ]; then
  echo "usage: $0 BASE_SHA FINAL_HEAD_SHA" >&2
  exit 1
fi

base=$1
head=$2
git rev-parse --verify "$base^{commit}" >/dev/null
git rev-parse --verify "$head^{commit}" >/dev/null
if ! git merge-base --is-ancestor "$base" "$head"; then
  echo "review base is not an ancestor of the head: $base..$head" >&2
  exit 1
fi

paths=$(git diff --name-only --no-renames "$base" "$head")
if [ -z "$paths" ]; then
  echo "no changed paths: $base..$head" >&2
  exit 2
fi

code_paths=$(printf '%s\n' "$paths" | awk '
  /^(include|lib|src|unittests|tests|fuzzer|deps|cmake|scripts|tools)\// ||
  /^\.github\/workflows\// ||
  /^(CMakeLists\.txt|Makefile|Dockerfile|\.gitmodules)$/ { print }
')

if [ -z "$code_paths" ]; then
  echo "receipt-only diff: no implementation, test, dependency, build, or workflow paths in $base..$head" >&2
  exit 2
fi

echo "code-bearing paths in $base..$head:"
printf '%s\n' "$code_paths"
echo "Inspect the complete adjacent diff and map each claimed behavior to reviewed code paths."
