#!/bin/sh
set -eu
variant=$1
case "$variant" in full|btc) ;; *) exit 2;; esac
run=/root/build/native-final-$variant
mkdir "$run"
cd "$run"
/root/build/$variant/bin/firmware-unit --gtest_output=xml:firmware.xml
/root/build/$variant/bin/board-unit --gtest_output=xml:board.xml
/root/build/$variant/bin/crypto-unit --gtest_output=xml:crypto.xml
