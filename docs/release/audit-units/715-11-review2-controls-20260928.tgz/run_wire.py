import argparse,os,pathlib,socket,subprocess,time,json,hashlib
p=argparse.ArgumentParser();p.add_argument('variant',choices=['full','btc']);p.add_argument('--binary');a=p.parse_args()
root=pathlib.Path('/private/tmp/kk715-stack11-run3');ev=pathlib.Path('/private/tmp/kk715-stack11-round3-evidence')
build=ev/'storage'/a.variant
binary=pathlib.Path(a.binary) if a.binary else build/'bin/kkemu'
if not binary.is_file(): raise SystemExit('missing emulator binary: '+str(binary))
variant='bitcoin-only' if a.variant=='btc' else 'full'
case=ev/('wire-'+a.variant);case.mkdir(exist_ok=True)
port=12444 if a.variant=='full' else 12544
name='kk715-stack11-wire-'+a.variant
cmd=['docker','run','--rm','--platform','linux/amd64','--name',name,'-p',f'127.0.0.1:{port}:11044/udp','-p',f'127.0.0.1:{port+1}:11045/udp','-v',f'{binary.parent}:/bin-under-test:ro','-w','/tmp','7438e53933d4','/bin-under-test/'+binary.name]
log=(case/'emulator.log').open('wb');proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
try:
 with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
  s.settimeout(.5)
  ready=False
  for attempt in range(40):
   if proc.poll() is not None: raise RuntimeError('emulator exited; inspect log')
   s.sendto(b'PINGPING',('127.0.0.1',port))
   try: ready=s.recv(64)==b'PONGPONG'
   except socket.timeout: continue
   if ready: break
  if not ready: raise RuntimeError('emulator readiness not established')
 env=os.environ.copy();env.update(KK_FORCE_UDP='1',KK_TRANSPORT_MAIN=f'127.0.0.1:{port}',KK_TRANSPORT_DEBUG=f'127.0.0.1:{port+1}',FW_VERSION='7.15.0',KK_FIRMWARE_VARIANT=variant,KK_RELEASE_MISSING_CAPABILITIES='entropy-audit-budget,osmosis-wire-guards,hive-release-review,storage-v19-kdf,solana-lut-attestation',PYTHONPATH=str(root/'deps/python-keepkey')+':'+str(root/'deps/python-keepkey/tests'))
 modules=['test_msg_solana_schema_v2.py','test_msg_solana_signtx.py','test_msg_solana_instruction_disclosure.py','test_msg_solana_display_disclosure.py','test_msg_signidentity.py','test_msg_cipherkeyvalue.py',str(root/'scripts/emulator/test_stack09_integration.py'),str(root/'scripts/emulator/test_stack10_regressions.py')]
 command=['/private/tmp/kk715-stack11-report-venv/bin/python','-m','pytest','-q','-ra','--tb=short','--junitxml='+str(case/'junit.xml')]+modules
 with (case/'pytest.log').open('wb') as out:
  result=subprocess.run(command,cwd=root/'deps/python-keepkey/tests',env=env,stdout=out,stderr=subprocess.STDOUT)
 (case/'receipt.json').write_text(json.dumps({'variant':variant,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'command':command,'exit':result.returncode},indent=2)+'\n')
 print('wire',variant,'exit',result.returncode,flush=True)
 raise SystemExit(result.returncode)
finally:
 subprocess.run(['docker','stop',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 proc.wait(timeout=30);log.close()
