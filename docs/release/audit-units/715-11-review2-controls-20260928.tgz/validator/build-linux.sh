#!/bin/sh
set -eu
cmake -C /root/keepkey-firmware/cmake/caches/emulator.cmake /root/keepkey-firmware -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_BUILD_TYPE=Debug
cmake --build . --target erc7730-validator-test -- -j6
ctest -V -R test-erc7730-validator
