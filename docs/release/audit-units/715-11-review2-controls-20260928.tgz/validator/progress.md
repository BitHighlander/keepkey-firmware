# Validator and Windows timer remediation (in progress)

Base: 8cd5561a241b7f5f5cb7068eb8bc3e2d30de166b. Main canonical SOP and master read.

Owned comments: 4118361301 (timer), 4118361360 (include path), 4118361390 (Windows validator socket backend), 4118361413 (EOF boundary).

Changes written in /private/tmp/kk715-stack11-run3:
- lib/board/timer.c: POSIX includes only under non-Windows; delay_us uses Sleep, ceiling division without overflowing uint32_t.
- tools/erc7730-validate/CMakeLists.txt: NOT WIN32 like kkemu; explicit crypto includes; actual CLI test registered in CTest and a custom target.
- tools/erc7730-validate/main.c: fread one byte beyond capacity; distinct ferror diagnostic; max-sized reads reach the device parser.
- tools/erc7730-validate/test_cli.py: 12 subprocess tests against actual executable, independent valid C773 fixture and malformed neighbors, file bounds/errors.
- Root CMakeLists.txt: xunit depends on erc7730-validator-test so hosted native test jobs execute the CLI regression.

Already executed controls:
1. Baseline main.c compiles with cc -std=gnu99 -Werror=implicit-function-declaration -Iinclude: success. Tracked include/trezor/crypto symlink resolves SHA2 header. Include comment compile failure does not reproduce on this head. Added direct directory as explicit dependency.
2. Baseline timer.c compiles with x86_64-w64-mingw32-gcc -DEMULATOR -DBITCOIN_ONLY=0 -std=gnu99 -Werror=implicit-function-declaration -Iinclude: success. This head still includes unistd.h, so claimed undeclared-usleep failure does not reproduce. Baseline object imports usleep and Sleep.
3. Fixed timer.c cross-compiles with same flags: success; symbol inventory imports Sleep only, no usleep/signal/alarm.
4. clang-format 20 applied to changed C files; git diff --check passes.

Pending actual native validator build/tests and baseline controls; Windows supported DLL build/graph check. Root restoring clean pinned dependencies first.

5. Native harness compiles actual timer.c with `_WIN32` and a Sleep interception declaration (not a Windows runtime): delay_us inputs 0,1,999,1000,1001,UINT32_MAX produce 0,1,1,1,2,4294968 milliseconds; delay_ms runs queued runnable and advances 3 ticks; callback delay advances 5 ticks and invokes expected callbacks. All pass. Baseline timer source fails the Windows Sleep assertion, exit -6, saved timer-baseline-negative.log. Fixed stdout saved timer-fixed.log. This verifies branch arithmetic/control flow, not Windows scheduler accuracy.
