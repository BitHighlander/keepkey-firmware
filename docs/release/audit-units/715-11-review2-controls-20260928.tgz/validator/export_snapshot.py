import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path('/private/tmp/kk715-stack11-run3')
out = Path('/private/tmp/kk715-stack11-validator-source')
out.mkdir(exist_ok=False)
entries = subprocess.check_output(['git', 'ls-files', '--stage', '-z'], cwd=root).split(b'\0')
manifest = {}
for entry in entries:
    if not entry:
        continue
    meta, raw_path = entry.split(b'\t', 1)
    mode, sha, stage = meta.decode().split()
    relative = raw_path.decode()
    src, dst = root / relative, out / relative
    dst.parent.mkdir(parents=True, exist_ok=True)
    if mode == '160000':
        dst.mkdir()
        data = subprocess.check_output(['git', 'archive', sha], cwd=src)
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            archive.extractall(dst, filter='fully_trusted')
        manifest[relative] = {'gitlink': sha}
    elif src.is_symlink():
        target = os.readlink(src)
        dst.symlink_to(target)
        manifest[relative] = {'symlink': target}
    else:
        shutil.copy2(src, dst)
        manifest[relative] = {'sha256': hashlib.sha256(src.read_bytes()).hexdigest()}
relative = 'tools/erc7730-validate/test_cli.py'
shutil.copy2(root / relative, out / relative)
manifest[relative] = {'sha256': hashlib.sha256((root / relative).read_bytes()).hexdigest()}
Path('/private/tmp/kk715-stack11-round3-evidence/validator/source-snapshot.json').write_text(json.dumps(manifest, indent=2)+'\n')
print('Exported', len(manifest), 'tracked paths and pinned direct dependencies to', out)
