#!/bin/sh
set -eu
clang -DEMULATOR -I/root/keepkey-firmware/include -I/root/build/include -c /evidence/main-baseline.c -o /evidence/main-baseline.o
cd /root/build/tools/erc7730-validate
/usr/bin/clang -g   /evidence/main-baseline.o  -o /evidence/erc7730-validate-baseline ../../lib/libkkfirmware.a ../../lib/libkkfirmware.keepkey.a ../../lib/libkkboard.a ../../lib/libkkboard.keepkey.a ../../lib/libkkvariant.keepkey.a ../../lib/libkkvariant.salt.a ../../lib/libkktransport.a ../../lib/libtrezorcrypto.a ../../lib/libqrcodegenerator.a ../../lib/libSecAESSTM32.a ../../lib/libkkrand.a ../../lib/libkkemulator.a 

set +e
python3 /root/keepkey-firmware/tools/erc7730-validate/test_cli.py /evidence/erc7730-validate-baseline -v > /evidence/cli-baseline-negative.log 2>&1
status=$?
cat /evidence/cli-baseline-negative.log
[ "$status" -eq 1 ]
