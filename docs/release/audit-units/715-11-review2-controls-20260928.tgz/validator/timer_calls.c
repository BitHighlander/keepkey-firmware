#include "keepkey/board/timer.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
static unsigned long last_sleep;
static unsigned calls;
static unsigned callbacks;
static unsigned runnables;
void Sleep(unsigned long ms) { last_sleep = ms; calls++; }
int usleep(useconds_t us) { (void)us; return 0; }
static void callback(void) { callbacks++; }
static void runnable(void *context) { assert(context == &runnables); runnables++; }
int main(void) {
  const uint32_t inputs[] = {0, 1, 999, 1000, 1001, UINT32_MAX};
  const unsigned long expected[] = {0, 1, 1, 1, 2, 4294968};
  timer_init();
  for (unsigned i = 0; i < sizeof(inputs) / sizeof(inputs[0]); i++) {
    calls = 0;
    delay_us(inputs[i]);
    assert(calls == 1);
    assert(last_sleep == expected[i]);
  }
  assert(getSysTime() == 0);
  calls = 0;
  post_delayed(runnable, &runnables, 2);
  delay_ms(3);
  assert(calls == 3 && last_sleep == 1 && getSysTime() == 3 && runnables == 1);
  calls = 0;
  delay_ms_with_callback(5, callback, 2);
  assert(calls == 5 && last_sleep == 1 && getSysTime() == 8 && callbacks == 2);
  puts("Windows timer branch: 6 delay_us boundaries, delay_ms runnable, and callback continuation passed");
}
