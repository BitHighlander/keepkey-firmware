import pathlib
import subprocess

root = pathlib.Path('/private/tmp/kk715-stack11-run3')
src = pathlib.Path('/private/tmp/kk715-stack11-validator-source')
p = pathlib.Path('/private/tmp/kk715-stack11-round3-evidence/validator')
cmakefile = src / 'tools/erc7730-validate/CMakeLists.txt'
fixed = cmakefile.read_bytes()
baseline = subprocess.check_output(['git', 'show', '8cd5561a241b7f5f5cb7068eb8bc3e2d30de166b:tools/erc7730-validate/CMakeLists.txt'], cwd=root)
try:
    cmakefile.write_bytes(baseline)
    with (p / 'windows-baseline-configure.log').open('w') as log:
        subprocess.run(['cmake', '-S', str(src), '-B', str(p / 'windows')], stdout=log, stderr=subprocess.STDOUT, check=True)
    with (p / 'windows-baseline-negative.log').open('w') as log:
        result = subprocess.run(['cmake', '--build', str(p / 'windows'), '--target', 'erc7730-validate', '-j6'], stdout=log, stderr=subprocess.STDOUT)
    diagnostics = (p / 'windows-baseline-negative.log').read_text()
    assert result.returncode != 0, 'Baseline Windows validator unexpectedly built'
    assert 'arpa/inet.h' in diagnostics, diagnostics[-2000:]
    print('Baseline validator target fails on unsupported arpa/inet.h, as expected')
finally:
    cmakefile.write_bytes(fixed)
    with (p / 'windows-fixed-configure.log').open('w') as log:
        subprocess.run(['cmake', '-S', str(src), '-B', str(p / 'windows')], stdout=log, stderr=subprocess.STDOUT, check=True)

r = subprocess.run(['cmake', '--build', str(p / 'windows'), '--target', 'help'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, check=True)
(p / 'windows-fixed-targets.log').write_text(r.stdout)
assert 'erc7730-validate' not in r.stdout
assert 'kkemulator_dylib' in r.stdout
print('Fixed Windows graph excludes POSIX validator and retains supported DLL')
