# Block11 validator/Windows remediation receipt

Source commit: `36d9f32f0daac85d3baa68996e0c59112dffbf74`; reviewed baseline `8cd5561a241b7f5f5cb7068eb8bc3e2d30de166b`.
The final exported snapshot was checked byte-for-byte against this committed tree, including direct and used nested dependency pins. These are targeted software build/runtime checks, not physical-device or release acceptance.

## Dispositions

| Finding | Disposition and evidence |
| --- | --- |
| 4118361301 | Explicit Windows delay_us Sleep path rounds up safely through UINT32_MAX; POSIX headers remain POSIX-only. Actual MinGW DLL builds. Native Sleep-interception harness executes actual timer.c (six boundaries, queued runnable and callback continuation); baseline fails intended path assertion. Original claim of undeclared usleep does not reproduce: baseline retained unistd.h and compiled on installed MinGW. |
| 4118361360 | Direct crypto include dependency declared. Original missing SHA2 header failure does not reproduce on this head: tracked include/trezor/crypto symlink resolves it and baseline main.c object compile passed with only -Iinclude. Fixed actual native target builds. |
| 4118361390 | Validator shares standalone kkemu's POSIX support boundary and is gated out on Windows. Original CMake actual cross build fails arpa/inet.h; fixed graph omits validator and supported kkemulator_dylib builds. |
| 4118361413 | fread requests capacity+1, separately checks ferror, accepts exact reader capacity for parser evaluation. Actual CLI passes 12 tests; old main.c linked against same production parser libraries fails exactly exact-capacity and read-error cases while 10 neighbors pass. |
| Additional portability class defect | Full MinGW build found rng.c's remaining direct BCryptGenRandom branch lacked Windows declarations. Removed duplicated branch: every emulator uses existing emulatorRandom OS CSPRNG (Windows BCryptGenRandom; POSIX urandom; abort on failure). Old source compile fails, fixed source compile and complete DLL link pass. DLL imports BCryptGenRandom from bcrypt.dll. |

## Executed evidence

- `linux-final-build.log`: real validator custom target runs 12/12 tests; CTest also discovers and passes test-erc7730-validator. Root xunit depends on the custom target, so hosted native test jobs execute it.
- `cli-baseline-negative.log`: same real parser libraries with original main.c; 10 pass, exactly two expected failures. Valid C773 fixture passes, invalid magic/truncation/trailing bytes reject, capacity-minus-one reaches parser, capacity-plus-one and larger reject at reader, empty/missing/usage reject.
- `windows-final-build.log`: supported MinGW DLL fully builds against final committed sources; `windows-dll-imports.log` confirms bcrypt CSPRNG import.
- `windows-baseline-negative.log` and `windows-fixed-targets.log`: original validator graph fails on unsupported BSD include, fixed graph excludes target.
- `timer-fixed.log`, `timer-baseline-negative.log`: actual timer source branch assertions with Sleep interception.
- `rng-baseline-negative.log`, `rng-fixed-compile.log`: compiler-level regression control for discovered RNG portability failure.
- `source-snapshot.json`, `result.json`, `sha256.json`: pinned source and artifact identities.

Windows runtime/scheduler behavior was not executed on Windows; branch arithmetic is intercepted on macOS and the complete Windows image is cross-compiled. The CLI's reader capacity remains 1,048,054 bytes, above the device's 16,384-byte bound: the exact reader-capacity test expects parser rejection (status 1), distinguishing it from truncation misclassification (status 2). Source snapshots carry exact source bytes, not a claim of release binary provenance.

Owned changed paths:

- `CMakeLists.txt`
- `lib/board/timer.c`
- `lib/rand/rng.c`
- `tools/erc7730-validate/CMakeLists.txt`
- `tools/erc7730-validate/main.c`
- `tools/erc7730-validate/test_cli.py`
