#!/bin/sh
exec docker run --rm --platform linux/amd64 -v /private/tmp:/private/tmp -w "$PWD" 7438e53933d4 /usr/local/bin/protoc "$@"
